<script setup>
import { onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import {
  adminBanTeam,
  adminCreateChallenge,
  adminCreateGame,
  adminDeleteTeam,
  adminDeleteUser,
  adminListTeams,
  adminListUsers,
  adminUnbanTeam,
  logout,
} from "@shared-api/services";
import { clearSession } from "@shared-api/http";

const router = useRouter();
const activeTab = ref("users");
const notice = ref("");

const users = ref([]);
const userOffset = ref(0);
const userSize = ref(20);

const teams = ref([]);
const teamGameId = ref("1");
const teamSize = ref(20);
const teamOffset = ref(0);
const teamSearch = ref("");

const createGameForm = ref({
  title: "",
  description: "",
  startTime: "",
  endTime: "",
});

const createChallengeForm = ref({
  gameId: "",
  title: "",
  category: "web",
  description: "",
  score: "100",
  difficulty: "easy",
  isStatic: true,
  needHostMount: false,
  imageName: "nginx:alpine",
  containerPort: "80",
  flag: "",
});

function setNotice(text) {
  notice.value = text;
}

async function loadUsers() {
  try {
    const result = await adminListUsers({ offset: Number(userOffset.value), size: Number(userSize.value) });
    users.value = Array.isArray(result.data) ? result.data : [];
    setNotice(`用户列表加载完成，共 ${users.value.length} 条`);
  } catch (error) {
    setNotice(error.message || "加载用户失败");
  }
}

async function removeUser(item) {
  if (!item?.userId || !item?.email) {
    setNotice("用户数据不完整，无法删除");
    return;
  }

  try {
    await adminDeleteUser({ userId: item.userId, email: item.email });
    setNotice(`已删除用户 ${item.username}`);
    await loadUsers();
  } catch (error) {
    setNotice(error.message || "删除用户失败");
  }
}

async function loadTeams() {
  try {
    const result = await adminListTeams({
      game_id: String(teamGameId.value),
      size: Number(teamSize.value),
      offset: Number(teamOffset.value),
      search: teamSearch.value,
    });
    teams.value = Array.isArray(result.data) ? result.data : [];
    setNotice(`队伍列表加载完成，共 ${teams.value.length} 条`);
  } catch (error) {
    setNotice(error.message || "加载队伍失败");
  }
}

async function banTeam(teamId) {
  try {
    await adminBanTeam({ teamId, reason: "admin panel" });
    setNotice(`已封禁队伍 ${teamId}`);
    await loadTeams();
  } catch (error) {
    setNotice(error.message || "封禁失败");
  }
}

async function unbanTeam(teamId) {
  try {
    await adminUnbanTeam({ teamId });
    setNotice(`已解封队伍 ${teamId}`);
    await loadTeams();
  } catch (error) {
    setNotice(error.message || "解封失败");
  }
}

async function deleteTeam(teamId) {
  try {
    await adminDeleteTeam({ teamId });
    setNotice(`已删除队伍 ${teamId}`);
    await loadTeams();
  } catch (error) {
    setNotice(error.message || "删除队伍失败");
  }
}

async function submitCreateGame() {
  try {
    await adminCreateGame({
      title: createGameForm.value.title,
      description: createGameForm.value.description,
      startTime: createGameForm.value.startTime,
      endTime: createGameForm.value.endTime,
    });
    setNotice("创建比赛成功");
  } catch (error) {
    setNotice(error.message || "创建比赛失败");
  }
}

async function submitCreateChallenge() {
  try {
    await adminCreateChallenge({
      gameId: String(createChallengeForm.value.gameId),
      title: createChallengeForm.value.title,
      category: createChallengeForm.value.category,
      description: createChallengeForm.value.description,
      score: Number(createChallengeForm.value.score),
      difficulty: createChallengeForm.value.difficulty,
      isStatic: Boolean(createChallengeForm.value.isStatic),
      needHostMount: Boolean(createChallengeForm.value.needHostMount),
      imageName: createChallengeForm.value.imageName,
      containerPort: Number(createChallengeForm.value.containerPort),
      flag: createChallengeForm.value.flag,
    });
    setNotice("创建题目成功");
  } catch (error) {
    setNotice(error.message || "创建题目失败");
  }
}

async function doLogout() {
  try {
    await logout();
  } catch (error) {
    // ignore
  }
  clearSession();
  router.push("/login");
}

onMounted(async () => {
  await loadUsers();
  await loadTeams();
});
</script>

<template>
  <div class="page admin-page">
    <header class="topbar">
      <h2>CTF Admin 控制台</h2>
      <div class="row">
        <button @click="doLogout">退出</button>
      </div>
    </header>

    <div class="admin-layout">
      <aside class="card side-menu">
        <button :class="{ active: activeTab === 'users' }" @click="activeTab = 'users'">用户管理</button>
        <button :class="{ active: activeTab === 'teams' }" @click="activeTab = 'teams'">队伍管理</button>
        <button :class="{ active: activeTab === 'games' }" @click="activeTab = 'games'">比赛管理</button>
        <button :class="{ active: activeTab === 'challenges' }" @click="activeTab = 'challenges'">题目管理</button>
      </aside>

      <main class="card content-panel" v-if="activeTab === 'users'">
        <h3>用户管理</h3>
        <div class="toolbar">
          <label>offset</label>
          <input type="number" v-model="userOffset" />
          <label>size</label>
          <input type="number" v-model="userSize" />
          <button @click="loadUsers">刷新</button>
        </div>

        <table>
          <thead>
            <tr>
              <th>UID</th>
              <th>用户名</th>
              <th>邮箱</th>
              <th>角色</th>
              <th>分数</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in users" :key="u.userId">
              <td>{{ u.userId }}</td>
              <td>{{ u.username }}</td>
              <td>{{ u.email }}</td>
              <td>{{ u.role }}</td>
              <td>{{ u.score }}</td>
              <td>
                <button class="danger" @click="removeUser(u)">删除</button>
              </td>
            </tr>
          </tbody>
        </table>
      </main>

      <main class="card content-panel" v-if="activeTab === 'teams'">
        <h3>队伍管理</h3>
        <div class="toolbar">
          <label>game_id</label>
          <input v-model="teamGameId" />
          <label>size</label>
          <input type="number" v-model="teamSize" />
          <label>offset</label>
          <input type="number" v-model="teamOffset" />
          <label>search</label>
          <input v-model="teamSearch" />
          <button @click="loadTeams">刷新</button>
        </div>

        <table>
          <thead>
            <tr>
              <th>TeamId</th>
              <th>队名</th>
              <th>成员</th>
              <th>分数</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="t in teams" :key="t.teamId">
              <td>{{ t.teamId }}</td>
              <td>{{ t.teamName }}</td>
              <td>{{ Array.isArray(t.teamMembers) ? t.teamMembers.join(', ') : '' }}</td>
              <td>{{ t.teamScore }}</td>
              <td class="actions">
                <button @click="banTeam(t.teamId)">封禁</button>
                <button @click="unbanTeam(t.teamId)">解封</button>
                <button class="danger" @click="deleteTeam(t.teamId)">删除</button>
              </td>
            </tr>
          </tbody>
        </table>
      </main>

      <main class="card content-panel" v-if="activeTab === 'games'">
        <h3>创建比赛</h3>
        <div class="form-grid">
          <label>标题</label>
          <input v-model="createGameForm.title" />
          <label>描述</label>
          <textarea v-model="createGameForm.description" rows="3"></textarea>
          <label>开始时间 RFC3339</label>
          <input v-model="createGameForm.startTime" placeholder="2026-03-10T10:00:00Z" />
          <label>结束时间 RFC3339</label>
          <input v-model="createGameForm.endTime" placeholder="2026-03-10T18:00:00Z" />
          <button @click="submitCreateGame">创建比赛</button>
        </div>
      </main>

      <main class="card content-panel" v-if="activeTab === 'challenges'">
        <h3>创建题目</h3>
        <div class="form-grid">
          <label>gameId</label>
          <input v-model="createChallengeForm.gameId" />
          <label>标题</label>
          <input v-model="createChallengeForm.title" />
          <label>分类</label>
          <input v-model="createChallengeForm.category" />
          <label>描述</label>
          <textarea v-model="createChallengeForm.description" rows="3"></textarea>
          <label>分值</label>
          <input type="number" v-model="createChallengeForm.score" />
          <label>难度</label>
          <select v-model="createChallengeForm.difficulty">
            <option value="easy">easy</option>
            <option value="medium">medium</option>
            <option value="hard">hard</option>
          </select>
          <label>静态题</label>
          <select v-model="createChallengeForm.isStatic">
            <option :value="true">true</option>
            <option :value="false">false</option>
          </select>
          <label>需要挂载宿主机</label>
          <select v-model="createChallengeForm.needHostMount">
            <option :value="false">false</option>
            <option :value="true">true</option>
          </select>
          <label>镜像名 imageName</label>
          <input v-model="createChallengeForm.imageName" />
          <label>容器端口 containerPort</label>
          <input type="number" v-model="createChallengeForm.containerPort" />
          <label>flag</label>
          <input v-model="createChallengeForm.flag" />
          <button @click="submitCreateChallenge">创建题目</button>
        </div>
      </main>
    </div>

    <p class="notice">{{ notice }}</p>
  </div>
</template>
