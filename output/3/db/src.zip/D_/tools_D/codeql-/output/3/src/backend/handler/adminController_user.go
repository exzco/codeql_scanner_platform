package handler

import (
	"backend/model"
	"net/http"
	"golang.org/x/crypto/bcrypt"
	"backend/config"
	"github.com/gin-gonic/gin"
)

// // @summary 管理员仪表盘统计
// // @tags 管理员接口
// // @router /api/auth/admin/dashborad [get]
// func Dashboard(c *gin.Context) {

// }


// @summary 管理员列出所有用户
// @tags 管理员接口
// @router /api/auth/admin/users/list [get]
func AdminListUsers(c *gin.Context) {
	var req model.AdminListUsersRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var users []model.User
	if err := config.DB.Model(&model.User{}).Offset(req.Offset).Limit(req.Size).Find(&users).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{
			"error":err.Error(),
		})
		return
	}

	var count int64
	if err := config.DB.Model(&model.User{}).Count(&count).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{
			"error":err.Error(),
		})
		return
	}


	userData := make([]model.AdminListUsersResponse,len(users))
	for i,user := range users {
		userData[i] = model.AdminListUsersResponse{
			UserId: user.UserId,
			Username: user.Username,
			Email: user.Email,
			Role: user.Role,
			CreatedAt: user.CreatedAt,
			Score: user.Score,
			TeamId: user.TeamId,
		}
	}

	c.JSON(http.StatusOK,gin.H{
		"code":200,
		"message":"success",
		"total":count,
		"data":userData,
	})
	
}


// @summary 更新用户信息，先不写了暂时用不到


// @summary 用户密码修改
// @tags 管理员接口
// @router /api/auth/admin/users/changepassword [get]
func AdminChangeUsersPassword(c *gin.Context) {
	var req model.AdminChangePasswordRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var user model.User
	if err := config.DB.Where("email = ?",req.Email).First(&user).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	// 比对密码和确认密码
	if req.NewPassword != req.ConfirmPassword {
		c.JSON(http.StatusBadRequest, gin.H{"error": "新密码和确认密码不一致"})
		return
	}

	// 比对hash值
	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.OldPassword)); err != nil {
		c.JSON(400, gin.H{"error": "旧密码错误"})
		return
	}
	//生成新密码哈希
	NewPasswordHash, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		c.JSON(500, gin.H{"error": "failed to hash password"})
		return
	}
	// 更新密码
	user.PasswordHash = string(NewPasswordHash)
	if err := config.DB.Save(&user).Error;err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "密码修改成功"})
}

// @summary 删除用户
// @tags 管理员接口
// @router /api/auth/admin/deleteUser [post]
func AdminDeleteUser(c *gin.Context) {
	var req model.AdminDeleteUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	tx := config.DB.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
		}
	}()

	var user model.User
	// 检查该用户是否存在
	if err := tx.Where("user_id = ? AND email = ?", req.UserId, req.Email).First(&user).Error; err != nil {
		tx.Rollback()
		c.JSON(http.StatusNotFound, gin.H{"error": "未找到对应用户或查询失败"})
		return
	}

	if user.Role == "admin" {
		tx.Rollback()
		c.JSON(http.StatusForbidden, gin.H{"error": "不允许删除管理员账户"})
		return
	}

	// 执行删除
	if err := tx.Delete(&user).Error; err != nil {
		tx.Rollback()
		c.JSON(http.StatusInternalServerError, gin.H{"error": "删除用户失败"})
		return
	}

	// 提交事务
	if err := tx.Commit().Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "提交事务失败"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"code": 200,
		"message": "删除成功",
	})
}