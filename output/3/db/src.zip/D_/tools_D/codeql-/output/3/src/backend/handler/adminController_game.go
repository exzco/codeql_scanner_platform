package handler

import (
	"backend/config"
	"backend/model"
	"backend/util"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)


// @summary 创建比赛
// @tags 比赛接口
// @param model.GameRequest
// @success 200 {object} gin.H "返回创建结果"
// @router /api/auth/admin/gameCreate [post]
func CreateGame(c *gin.Context) {

	var req model.GameRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.game.createGame_1"})
		return
	}

	// 简单校验：开始时间必须早于结束时间
	if !req.StartTime.Before(req.EndTime) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "startTime must be before endTime"})
		return
	}

	// 把 DTO 映射到实际的 DB 模型，再插入 games 表
	game := model.Games{
		GameId:      util.GenerateHashID(req.Title),
		Title:       req.Title,
		Description: req.Description,
		StartTime:   req.StartTime,
		EndTime:     req.EndTime,
	}

	// 检查是否已存在同名比赛
	var exist model.Games
	if err := config.DB.Where("title = ?", game.Title).First(&exist).Error; err == nil {
		log.Printf("game with title '%s' already exists: %v", game.Title, exist)
		c.JSON(http.StatusBadRequest, gin.H{"error": "game with this title already exists"})
		return
	}

	if err := config.DB.Create(&game).Error; err != nil {
		log.Printf("create game failed: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建比赛失败", "detail": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "比赛创建成功", "data": game})
}

// @summary 删除比赛
// @tags 比赛接口
// @param model.DeleteGameRequest
// @success 200 {object} gin.H "返回删除结果"
// @router /api/auth/admin/gameDelete [post]
func DeleteGame(c *gin.Context) {
	var req model.DeleteGameRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.game.deleteGame_1"})
		return
	}

	if err := config.DB.Where("game_id = ?", req.GameId).Delete(&model.Games{}).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "删除比赛失败", "detail": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "比赛删除成功"})
}

// @summary 更新比赛
// @tags 比赛接口
// @param model.UpdateGameRequest
// @success 200 {object} gin.H "返回更新结果"
// @router /api/auth/admin/gameUpdate [post]
func UpdateGame(c *gin.Context) {
	var req model.UpdateGameRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.game.updateGame_1"})
		return
	}

	var game model.Games
	if err := config.DB.Where("game_id = ?", req.GameId).First(&game).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "比赛未找到"})
		return
	}

	// 更新非空字段
	if req.Title != "" { game.Title = req.Title }
	if req.Description != "" { game.Description = req.Description }
	if !req.StartTime.IsZero() { game.StartTime = req.StartTime }
	if !req.EndTime.IsZero() { game.EndTime = req.EndTime }

	if !game.StartTime.Before(game.EndTime) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "endTime 必须晚于 startTime"})
		return
	}

	if err := config.DB.Save(&game).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "更新比赛失败", "detail": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "比赛更新成功", "data": game})
}