package handler

import (
	"backend/config"
	"backend/model"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

// @summary 获取比赛列表
// @tags 比赛接口
// @success 200 {object} gin.H "返回比赛列表"
// @router /api/auth/gameList [get]
func GetGameList(c *gin.Context) {
	// 模拟比赛列表数据
	var games []model.Games
	if err := config.DB.Find(&games).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "无法获取比赛列表"})
		return
	}
	log.Printf("Retrieved games: %v", games)
	c.JSON(http.StatusOK, gin.H{"message": "success", "data": games})
}

// @summary 获取比赛详情
// @tags 比赛接口
// @param id path string true "比赛ID"
// @success 200 {object} gin.H "返回比赛详情"
// @router /api/auth/gameList/{id} [get]
func GetGameDetail(c *gin.Context) {
	// 获取比赛ID
	gameId := c.Param("id")
	// log.Printf("当前比赛 id: %v", gameId)

	var game model.Games
	if err := config.DB.Where("game_id = ?", gameId).First(&game).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "当前比赛信息未找到"})
		return
	}

	log.Printf("received game detail: %v", game)
	c.JSON(http.StatusOK, gin.H{"message": "success", "data": game})
}

