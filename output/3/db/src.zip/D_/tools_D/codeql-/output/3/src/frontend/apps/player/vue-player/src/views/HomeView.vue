<script setup>
import { computed, onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import AppShell from "@shared-ui/components/AppShell.vue";
import { createTeam, getGameList, getProfile, getTeamInfo, joinTeam, logout } from "@shared-api/services";
import { clearSession, getToken } from "@shared-api/http";

const router = useRouter();
const games = ref([]);
const selected = ref(null);
const inviteCode = ref("");
const teamName = ref("");
const message = ref("");
const isLoggedIn = ref(false);
const usingPreview = ref(false);

const PUBLIC_PREVIEW_GAMES = [
  {
    id: "preview-1",
    title: "平台公开预览赛",
    description: "未登录状态下展示的公开预览数据，登录后自动切换真实比赛列表。",
    startTime: "2026-03-20T09:00:00Z",
    endTime: "2026-03-20T18:00:00Z",
  },
  {
    id: "preview-2",
    title: "新手训练赛",
    description: "用于展示首页体验；进入比赛与队伍操作需要先登录。",
    startTime: "2026-03-24T10:00:00Z",
    endTime: "2026-03-24T19:00:00Z",
  },
];

function hasValidSession() {
  return Boolean(getToken());
}

function toUiGame(raw) {
  return {
    id: String(raw?.GameId || raw?.gameId || raw?.ID || raw?.id || ""),
    title: raw?.Title || raw?.title || "未命名比赛",
    description: raw?.Description || raw?.description || "暂无简介",
    startTime: raw?.StartTime || raw?.startTime || "",
    endTime: raw?.EndTime || raw?.endTime || "",
  };
}

function gameStatus(item) {
  const start = new Date(item.startTime || 0).getTime();
  const end = new Date(item.endTime || 0).getTime();
  const now = Date.now();
  if (now < start) return "未开始";
  if (now > end) return "已结束";
  return "进行中";
}

const current = computed(() => games.value.find((g) => g.id === selected.value));

function setPreviewGames() {
  const cached = localStorage.getItem("public_game_preview_cache");
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        games.value = parsed;
      } else {
        games.value = PUBLIC_PREVIEW_GAMES;
      }
    } catch (error) {
      games.value = PUBLIC_PREVIEW_GAMES;
    }
  } else {
    games.value = PUBLIC_PREVIEW_GAMES;
  }

  selected.value = games.value[0]?.id || null;
  usingPreview.value = true;
}

async function load() {
  isLoggedIn.value = hasValidSession();

  if (!isLoggedIn.value) {
    setPreviewGames();
    message.value = "当前为游客模式：可浏览比赛列表，登录后才能进入比赛和队伍操作。";
    return;
  }

  try {
    await getProfile();
    const result = await getGameList();
    const list = Array.isArray(result.data) ? result.data.map(toUiGame).filter((x) => x.id) : [];
    games.value = list;
    selected.value = games.value[0]?.id || null;
    usingPreview.value = false;
    localStorage.setItem("public_game_preview_cache", JSON.stringify(list));
  } catch (e) {
    setPreviewGames();
    message.value = (e.message || "加载失败") + "；已切换到预览列表。";
  }
}

async function goChallenge() {
  if (!current.value) return;

  if (!isLoggedIn.value) {
    message.value = "进入比赛前请先登录。";
    router.push("/login");
    return;
  }

  try {
    await getTeamInfo();
    const id = selected.value;
    const name = encodeURIComponent(current.value.title || "比赛");
    router.push(`/challenge/${id}?gameName=${name}`);
  } catch {
    message.value = "请先加入或创建队伍";
  }
}

function goTeam() {
  if (!isLoggedIn.value) {
    message.value = "队伍功能需要先登录。";
    router.push("/login");
    return;
  }
  router.push("/team");
}

async function doJoinTeam() {
  if (!isLoggedIn.value) {
    message.value = "加入队伍前请先登录。";
    router.push("/login");
    return;
  }

  try {
    await joinTeam(inviteCode.value.trim());
    message.value = "加入队伍成功";
  } catch (e) {
    message.value = e.message || "加入失败";
  }
}

async function doCreateTeam() {
  if (!isLoggedIn.value) {
    message.value = "创建队伍前请先登录。";
    router.push("/login");
    return;
  }

  try {
    await createTeam(teamName.value.trim());
    message.value = "创建队伍成功";
  } catch (e) {
    message.value = e.message || "创建失败";
  }
}

async function doLogout() {
  try {
    await logout();
  } catch {
    // ignore
  }
  clearSession();
  isLoggedIn.value = false;
  setPreviewGames();
  message.value = "已退出登录，当前为游客模式。";
}

onMounted(load);
</script>

<template>
  <AppShell title="比赛大厅">
    <template #actions>
      <button v-if="isLoggedIn" @click="router.push('/settings')">设置</button>
      <button v-if="isLoggedIn" @click="doLogout">退出</button>
      <button v-else @click="router.push('/login')">登录 / 注册</button>
    </template>

    <div class="layout layout-2">
      <aside class="card list">
        <h3>比赛列表</h3>
        <p class="hint" v-if="usingPreview">当前显示预览列表</p>
        <button
          v-for="g in games"
          :key="g.id"
          class="item"
          :class="{ active: selected === g.id }"
          @click="selected = g.id"
        >
          {{ g.title }}
          <small>{{ gameStatus(g) }}</small>
        </button>
      </aside>

      <main class="card detail" v-if="current">
        <h3>{{ current.title }}</h3>
        <p>{{ current.description }}</p>
        <p>开始: {{ current.startTime }}</p>
        <p>结束: {{ current.endTime }}</p>
        <div class="row">
          <button @click="goChallenge">进入比赛</button>
          <button @click="goTeam">队伍管理</button>
        </div>
        <hr />
        <div class="row wrap">
          <input v-model="inviteCode" placeholder="邀请码加入队伍" :disabled="!isLoggedIn" />
          <button @click="doJoinTeam">加入</button>
        </div>
        <div class="row wrap">
          <input v-model="teamName" placeholder="队伍名创建队伍" :disabled="!isLoggedIn" />
          <button @click="doCreateTeam">创建</button>
        </div>
        <p class="hint">{{ message }}</p>
      </main>
    </div>
  </AppShell>
</template>
