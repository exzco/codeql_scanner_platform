package cronJobs

import (
	"context"
	"fmt"
	"sync/atomic"
	"time"

	"backend/async_tasks"
	"backend/config"
	"backend/k8s"
	"backend/model"
	"backend/util/zaphelper"

	corev1 "k8s.io/api/core/v1"
	k8serrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

var containerJobRunning atomic.Bool

// StartContainerJob 启动定时巡检协程，每 60s 跑一轮
func StartContainerJob() {
	zaphelper.Sugar.Info("[CronJob] 容器巡检定时器已启动，间隔 60s")
	ticker := time.NewTicker(60 * time.Second)
	go func() {
		for range ticker.C {
			// 目的：防止上一轮还没跑完，下一轮又进来
			if !containerJobRunning.CompareAndSwap(false, true) {
				zaphelper.Sugar.Warn("[CronJob] 上一轮巡检仍在运行，跳过本轮")
				continue
			}
			go func() {
				defer containerJobRunning.Store(false)
				runContainerInspection()
			}()
		}
	}()
}

// ── 主调度 ──────────────────────────────────────────────────────

func runContainerInspection() {
	// 1. 处理已过期但还在跑的容器
	expireOverdueContainers()

	// 2. 让数据库状态与 K8s 真实状态保持一致
	reconcileDBWithK8s()

	// 3. 处理 pending 超时（卡死）的容器 → 重试
	retryStuckPendingContainers()
}


func expireOverdueContainers() {
	var containers []model.ContainerInstance
	if err := config.DB.
		Where("status = ? AND expires_at < ?", "running", time.Now()).
		Find(&containers).Error; err != nil {
		zaphelper.Sugar.Errorf("[CronJob·Expire] 查询过期容器失败: %v", err)
		return
	}

	for _, c := range containers {
		zaphelper.Sugar.Infow("[CronJob·Expire] 发现过期靶机，投递销毁任务",
			"instance_id", c.InstanceId, "expires_at", c.ExpiresAt)

		// 先把状态 置为 stopping，防止下一轮重复投递
		if err := config.DB.Model(&c).Update("status", "stopping").Error; err != nil {
			zaphelper.Sugar.Errorw("[CronJob·Expire] 更新 stopping 状态失败",
				"instance_id", c.InstanceId, "error", err)
			continue
		}

		if err := async_tasks.EnqueueStopContainer(async_tasks.ContainerTaskPayload{
			InstanceId: c.InstanceId,
			Namespace:  c.Namespace,
		}); err != nil {
			zaphelper.Sugar.Errorw("[CronJob·Expire] 投递 stop 任务失败，回滚状态",
				"instance_id", c.InstanceId, "error", err)
			// 回滚，等下一轮再处理
			config.DB.Model(&c).Update("status", "running")
		}
	}
}


func reconcileDBWithK8s() {
	var containers []model.ContainerInstance
	if err := config.DB.
		Where("status IN ?", []string{"running", "pending", "stopping"}).
		Find(&containers).Error; err != nil {
		zaphelper.Sugar.Errorf("[CronJob·Reconcile] 查询活跃容器失败: %v", err)
		return
	}

	for _, c := range containers {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		runtimeState := getK8sRuntimeState(ctx, c.Namespace, c.InstanceId)
		cancel()

		switch c.Status {

		case "running":
			if runtimeState == "not_found" || runtimeState == "error" {
				zaphelper.Sugar.Warnw("[CronJob·Reconcile] running 但 K8s 异常，纠正为 error",
					"instance_id", c.InstanceId, "k8s_state", runtimeState)
				config.DB.Model(&c).Update("status", "error")
			}

		case "pending":
			if runtimeState == "running" {
				zaphelper.Sugar.Infow("[CronJob·Reconcile] pending 但 K8s 已 running，纠正",
					"instance_id", c.InstanceId)
				config.DB.Model(&c).Update("status", "running")
			}
			if runtimeState == "error" {
				zaphelper.Sugar.Warnw("[CronJob·Reconcile] pending 但 K8s 报错，纠正为 error",
					"instance_id", c.InstanceId)
				config.DB.Model(&c).Update("status", "error")
			}

		case "stopping":
			if runtimeState == "not_found" {
				zaphelper.Sugar.Infow("[CronJob·Reconcile] stopping 但 K8s 已清除，纠正为 destroyed",
					"instance_id", c.InstanceId)
				config.DB.Model(&c).Update("status", "destroyed")
			}
		}
	}
}


func retryStuckPendingContainers() {
	deadline := time.Now().Add(-10 * time.Minute)
	var stuck []model.ContainerInstance
	if err := config.DB.
		Where("status = ? AND created_at < ?", "pending", deadline).
		Find(&stuck).Error; err != nil {
		zaphelper.Sugar.Errorf("[CronJob·Retry] 查询卡死 pending 容器失败: %v", err)
		return
	}

	for _, c := range stuck {
		zaphelper.Sugar.Warnw("[CronJob·Retry] pending 超时，尝试重新投递",
			"instance_id", c.InstanceId, "created_at", c.CreatedAt)

		// 查询题目镜像信息
		var challenge model.Challenge
		if err := config.DB.Where("challenge_id = ? AND game_id = ?", c.ChallengeId, c.GameId).
			First(&challenge).Error; err != nil {
			zaphelper.Sugar.Errorw("[CronJob·Retry] 查询题目信息失败，置为 error",
				"instance_id", c.InstanceId, "error", err)
			config.DB.Model(&c).Update("status", "error")
			continue
		}

		// 清理可能的 K8s 残留资源
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		_ = k8s.DeleteChallengeInstance(ctx, c.Namespace, c.InstanceId)
		cancel()

		// 重新投递 start 任务
		if err := async_tasks.EnqueueStartContainer(async_tasks.ContainerTaskPayload{
			InstanceId:    c.InstanceId,
			UserId:        c.UserId,
			TeamId:        c.TeamId,
			ChallengeId:   c.ChallengeId,
			GameId:        c.GameId,
			Namespace:     c.Namespace,
			ImageName:     challenge.ImageName,
			NeedHostMount: challenge.NeedHostMount,
			DynamicFlag:   c.DynamicFlag,
		}); err != nil {
			zaphelper.Sugar.Errorw("[CronJob·Retry] 重新投递 start 任务失败，置为 error",
				"instance_id", c.InstanceId, "error", err)
			config.DB.Model(&c).Update("status", "error")
			continue
		}

		// 重置 created_at，防止下一轮立刻再次判定为卡死
		config.DB.Model(&c).Update("created_at", time.Now())
	}
}


func getK8sRuntimeState(ctx context.Context, namespace, instanceID string) string {
	if k8s.Clientset == nil {
		return "unknown"
	}

	appName := fmt.Sprintf("chal-%s", instanceID)

	// 先看 Deployment 是否存在
	_, err := k8s.Clientset.AppsV1().Deployments(namespace).Get(ctx, appName, metav1.GetOptions{})
	if err != nil {
		if k8serrors.IsNotFound(err) {
			return "not_found"
		}
		return "unknown"
	}

	// Deployment 存在，再看 Pod 状态
	pods, err := k8s.Clientset.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: fmt.Sprintf("app=%s", appName),
	})
	if err != nil || len(pods.Items) == 0 {
		return "pending"
	}

	for _, pod := range pods.Items {
		// 检查容器级别的致命状态
		for _, cs := range pod.Status.ContainerStatuses {
			if cs.State.Waiting != nil {
				switch cs.State.Waiting.Reason {
				case "CrashLoopBackOff", "ErrImagePull", "ImagePullBackOff",
					"CreateContainerConfigError", "CreateContainerError", "RunContainerError":
					return "error"
				}
			}
			if cs.State.Terminated != nil && cs.State.Terminated.ExitCode != 0 {
				return "error"
			}
		}

		if pod.Status.Phase == corev1.PodFailed {
			return "error"
		}

		// 有一个 Ready 的 Running Pod 就算健康
		if pod.Status.Phase == corev1.PodRunning && isPodReady(pod) {
			return "running"
		}
	}

	return "pending"
}

func isPodReady(pod corev1.Pod) bool {
	for _, cond := range pod.Status.Conditions {
		if cond.Type == corev1.PodReady && cond.Status == corev1.ConditionTrue {
			return true
		}
	}
	return false
}
