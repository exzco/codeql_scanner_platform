package async_tasks

import (
	"backend/util/zaphelper"
	"os"

	"github.com/hibiken/asynq"

)

var AsynqClient *asynq.Client
var server *asynq.Server
var inspector *asynq.Inspector

// 任务类型常量
const (
	TypeStartContainer = "container:start"
	TypeStopContainer  = "container:stop"
	TypeSyncScore      = "rank:sync"
)


func InitMessageQuene() {
    addr := os.Getenv("REDIS_ADDR")
    if addr == "" {
        addr = "localhost:6379"
    }
    password := os.Getenv("REDIS_PASSWORD")
    if password == "" {
    	password = "wsh_laribely"
    }
    
    redisOption := asynq.RedisClientOpt{
        Addr: addr,
        Password: password,
        DB: 1,
    }
    asynqConfig := asynq.Config{
        Concurrency: 30,
        Queues: map[string]int {
            "critical": 5,
            "common": 3,
            "low": 2,
        },
        StrictPriority: true,
        Logger: zaphelper.NewZapLogger(zaphelper.Logger),
    }
    AsynqClient = asynq.NewClient(redisOption)
    inspector = asynq.NewInspector(redisOption)
    server = asynq.NewServer(redisOption,asynqConfig,)   

    mux := asynq.NewServeMux()
    mux.HandleFunc(TypeStartContainer, HandleStartContainerTask)
    mux.HandleFunc(TypeStopContainer, HandleStopContainerTask)
    mux.HandleFunc(TypeSyncScore, HandleSyncScoreTask)
    
    // 启动一个协程监听队列是否有任务
    go func() {
        if err := server.Run(mux); err != nil {
            zaphelper.Sugar.Errorf("消息队列启动失败: %v", err)
        }
    }()
}



