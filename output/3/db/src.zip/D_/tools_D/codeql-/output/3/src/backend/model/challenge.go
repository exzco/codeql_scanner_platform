package model

import "time"

type Difficulty = string

const (
	DifficultyHard   Difficulty = "hard"
	DifficultyMedium Difficulty = "medium"
	DifficultyEasy   Difficulty = "easy"
	DifficultyBasic  Difficulty = "basic"
)

// db
type Challenge struct {
	ChallengeId   string     `gorm:"primaryKey;type:varchar(16);not null"`
	GameId        string     `gorm:"index;not null"`
	Title         string     `gorm:"type:varchar(64);not null"`
	Category      string     `gorm:"type:varchar(16);not null"`
	Description   string     `gorm:"type:text"`
	Score         int        `gorm:"type:integer;not null"`
	Difficulty    Difficulty `gorm:"type:varchar(16);not null"`
	IsStatic      *bool      `gorm:"not null;default:true"`      // 静态题目
	NeedHostMount bool       `gorm:"not null;default:false"`     // 是否需要挂载宿主机路径到 /host
	Flag          string     `gorm:"type:varchar(255);not null"` // 静态 flag,用于 crypto,misc reverse 等题目，动态环境的题目 flag 在创建 pod 时注入到环境变量中，存放在 container 表
	SolveCount    uint       `gorm:"not null;default:0"`         // 解出数
	ImageName     string     `gorm:"type:varchar(128);not null"` // 容器镜像名
	ContainerPort int32      `gorm:"not null;default:80"`         // 容器内服务监听端口
}

type Solve struct {
	UserId       string    `gorm:"uniqueIndex:idx_user_challenge;not null"`
	GameId       string    `gorm:"not null"`
	ChallengeId  string    `gorm:"uniqueIndex:idx_user_challenge;not null"`
	SolvedAtTime time.Time `gorm:"autoCreateTime"`
	Score        int       `gorm:"type:integer;not null"`
}

type Submissions struct {
	UserID            string    `gorm:"not null"`
	GameID            string    `gorm:"not null"`
	ChallengeID       string    `gorm:"not null"`
	SubmittedTime     time.Time `gorm:"autoCreateTime"`
	SubmittedFlagHash string    `gorm:"type:varchar(255);not null"`
}
type CreateChallengeRequest struct {
	GameId        string     `json:"gameId" binding:"required"`
	Title         string     `json:"title" binding:"required"`
	Category      string     `json:"category" binding:"required"`
	Description   string     `json:"description" binding:"required"`
	Score         int        `json:"score" binding:"required"`
	Difficulty    Difficulty `json:"difficulty" binding:"required"`
	IsStatic      *bool      `json:"isStatic" binding:"required"`
	NeedHostMount bool       `json:"needHostMount"`
	Flag          string     `json:"flag"`
	ImageName     string     `json:"imageName" binding:"required"`
	ContainerPort int32      `json:"containerPort"`
}

type ChallengeResponse struct {
	ChallengeId string `json:"challengeId"`
	GameId      string `json:"gameId"`
	Title       string `json:"title"`
	Category    string `json:"category"`
	Score       int    `json:"score"`
	Difficulty  string `json:"difficulty"`
	IsStatic    bool   `json:"isStatic"`
	IsSolved    bool   `json:"isSolved"` // 动态计算字段，不存数据库
}

type SubmitFlagRequest struct {
	Flag string `json:"flag" binding:"required"`
}

type DeleteChallengeRequest struct {
	ChallengeId string `json:"challengeId" binding:"required"`
	GameId      string `json:"gameId" binding:"required"`
}

type UpdateChallengeRequest struct {
	ChallengeId   string     `json:"challengeId" binding:"required"`
	GameId        string     `json:"gameId" binding:"required"`
	Title         string     `json:"title"`
	Category      string     `json:"category"`
	Description   string     `json:"description"`
	Score         int        `json:"score"`
	Difficulty    Difficulty `json:"difficulty"`
	IsStatic      bool       `json:"isStatic"`
	NeedHostMount *bool      `json:"needHostMount"`
	Flag          string     `json:"flag"`
	ContainerPort *int32     `json:"containerPort"`
}

type GetChallengeListRequest struct {
	GameId string `json:"gameId" binding:"required"`
}
