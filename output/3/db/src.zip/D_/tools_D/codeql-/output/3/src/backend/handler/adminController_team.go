package handler

import (
	"backend/model"
	"net/http"
	"backend/config"
	"github.com/gin-gonic/gin"
)

// @summary 管理员获取所有队伍列表
// @tags 队伍管理
// @param AdminListTeamsRequest
// @router /api/auth/admin/listTeams [post]
func AdminListTeams (c *gin.Context) {
	var req model.AdminListTeamsRequest 
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	sqlQuery := config.DB.Where("game_id = ?",req.GameId)

	// 模糊查询这块后面再补充
	if req.Search != "" {
		sqlQuery = sqlQuery.Where("team_name LIKE ?", "%"+req.Search+"%")
	}

	var teams []model.Team
	if err := sqlQuery.Offset(req.Offset).Limit(req.Size).Find(&teams).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.AdminListTeams_2"})
		return
	}

	var count int64
	countQuery := config.DB.Model(&model.Team{}).Where("game_id = ?",req.GameId)
	if req.Search != "" {
		countQuery = countQuery.Where("team_name LIKE ?", "%"+req.Search+"%")
	}
	if err := countQuery.Count(&count).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.AdminListTeams_3"})
		return
	}

	var users []model.User
    if err := config.DB.Find(&users).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.AdminListTeams_4"})
		return
	}

	var userMap = make(map[string]model.User)
	for _, user := range users {
		userMap[user.Username] = user
	}
	
	teamData := make([]model.AdminListTeamsResponse, 0, len(teams))
	for _, team := range teams {
		
		var validMembers []string
		for _, memberName := range team.Members {
			if _, ok := userMap[memberName]; ok {
				validMembers = append(validMembers, memberName)
			}
		}

		
		teamData = append(teamData, model.AdminListTeamsResponse{
			TeamId:      team.TeamId, 
			TeamName:    team.TeamName,
			TeamMembers: validMembers, 
			TeamScore:   team.Score,
		})
	}

	c.JSON(http.StatusOK, gin.H{
		"code":  200,
		"total": count,
		"data":  teamData,
	})
}

// @summary 管理员封禁队伍
// @tags 队伍管理
// @param model.AdminBanTeamRequest
// @router /api/auth/admin/banTeams [post]
func AdminBanTeam(c *gin.Context) {
	var req model.AdminBanTeamRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var team model.Team
	if err := config.DB.Where("team_id = ?",req.TeamId).First(&team).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.AdminBanTeam_2"})
		return
	}

	if team.TeamStatus == "banned" {
		c.JSON(http.StatusBadRequest,gin.H{"error":"Team is already banned","position":"handler.AdminBanTeam_3"})
		return
	}

	// 1. 封禁队伍
	if err := config.DB.Model(&team).Update("team_status", "banned").Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminBanTeam_4"})
		return
	}

	// 2. 查询该队伍做出的题目，得分清零，删除记录，解出数减一
	var solves []model.Solve
	if err := config.DB.Where("team_id = ?", req.TeamId).Find(&solves).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminBanTeam_5"})
		return
	}

	var challenge model.Challenge

	for _, solve := range solves {
		if err := config.DB.Delete(&solve).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminBanTeam_6"})
			return
		}

		if err := config.DB.Where("challenge_id = ? AND game_id = ?",solve.ChallengeId,solve.GameId).First(&challenge).Error; err != nil {
			c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.AdminBanTeam_7"})
			return
		}

		if err := config.DB.Model(&model.Challenge{}).Where("challenge_id = ? AND game_id = ?", solve.ChallengeId,solve.GameId).Update("solve_count", challenge.SolveCount-1).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminBanTeam_8"})
			return
		}

	}	
}


// @summary 管理员解封队伍
// @tags 队伍管理
// @param model.AdminUnbanTeamRequest
// @router /api/auth/admin/unbanTeams [post]
func AdminUnbanTeam(c *gin.Context) {
	var req model.AdminUnbanTeamRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var team model.Team
	if err := config.DB.Where("team_id = ?", req.TeamId).First(&team).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminUnbanTeam_2"})
		return
	}

	if team.TeamStatus != "banned" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Team is not banned", "position": "handler.AdminUnbanTeam_3"})
		return
	}

	// 恢复状态为 pending，或者其他未封禁状态
	if err := config.DB.Model(&team).Update("team_status", "pending").Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminUnbanTeam_4"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"code": 200, "message": "Team unbanned successfully"})
}


// @summary 管理员删除队伍
// @tags 队伍管理
// @param model.AdminDeleteTeamRequest
// @router /api/auth/admin/deleteTeam [post]
func AdminDeleteTeam(c *gin.Context) {
	var req model.AdminDeleteTeamRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var team model.Team
	if err := config.DB.Where("team_id = ?", req.TeamId).First(&team).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminDeleteTeam_2"})
		return
	}

	// 清理团队成员的 TeamId 字段
	if err := config.DB.Model(&model.User{}).Where("team_id = ?", req.TeamId).Update("team_id", nil).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminDeleteTeam_3"})
		return
	}

	// 删除团队的所有解题记录
	var solves []model.Solve
	if err := config.DB.Where("team_id = ?", req.TeamId).Find(&solves).Error; err == nil {
		for _, solve := range solves {
			config.DB.Delete(&solve)
		}
	}
		var challenge model.Challenge

	for _, solve := range solves {
		if err := config.DB.Delete(&solve).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminBanTeam_6"})
			return
		}

		if err := config.DB.Where("challenge_id = ? AND game_id = ?",solve.ChallengeId,solve.GameId).First(&challenge).Error; err != nil {
			c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.AdminBanTeam_7"})
			return
		}

		if err := config.DB.Model(&model.Challenge{}).Where("challenge_id = ? AND game_id = ?", solve.ChallengeId,solve.GameId).Update("solve_count", challenge.SolveCount-1).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminBanTeam_8"})
			return
		}

	}
	

	// 删除团队
	if err := config.DB.Delete(&team).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.AdminDeleteTeam_4"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"code": 200, "message": "Team deleted successfully"})
}