package async_tasks

import (
	"backend/config"
	"backend/model"
	"backend/util/zaphelper"
	"context"
	"fmt"
	"encoding/json"

	"github.com/hibiken/asynq"
	"gorm.io/gorm"
)


type ScoreTaskPayload struct {
	UserId      string
	ChallengeId string
	GameId      string
	Score       int
}

// 压入一个核算分数的 mq
func EnqueueSyncScore(payload ScoreTaskPayload) error {
	p, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	taskID := fmt.Sprintf("sync_score_u%s_c%s_g%s", payload.UserId, payload.ChallengeId, payload.GameId)
	task := asynq.NewTask(TypeSyncScore, p, asynq.MaxRetry(3), asynq.Queue("low"), asynq.TaskID(taskID))
	_, err = AsynqClient.Enqueue(task)
	return err
}


// HandleSyncScoreTask 异步处理高耗时间的事务（核对加分，更新排行榜）
func HandleSyncScoreTask(ctx context.Context, t *asynq.Task) error {
	var p ScoreTaskPayload
	if err := json.Unmarshal(t.Payload(), &p); err != nil {
		return err
	}
	
	tx := config.DB.Begin()
	if err := tx.Model(&model.User{}).Where("user_id = ?", p.UserId).UpdateColumn("score", gorm.Expr("score + ?", p.Score)).Error; err != nil {
		tx.Rollback()
		return err
	}
	if err := tx.Model(&model.Challenge{}).Where("challenge_id = ? AND game_id = ?", p.ChallengeId, p.GameId).UpdateColumn("solve_count", gorm.Expr("solve_count + ?", 1)).Error; err != nil {
		tx.Rollback()
		return err
	}
	var user model.User
	if err := tx.Where("user_id = ?", p.UserId).First(&user).Error; err != nil {
		tx.Rollback()
		return err
	}
	if err := tx.Model(&model.Team{}).Where("team_id = ?", user.TeamId).UpdateColumn("score", gorm.Expr("score + ?", p.Score)).Error; err != nil {
		tx.Rollback()
		return err
	}
	if err := tx.Commit().Error; err != nil {
		return err
	}
	
	var team model.Team
	if err := config.DB.Where("team_id = ?", user.TeamId).First(&team).Error; err == nil {
		config.RDB.ZIncrBy(config.Ctx, "scoreboard", float64(p.Score), team.TeamName)
		
		zaphelper.Sugar.Infow("分数与排行榜同步成功", 
			"user_id", p.UserId, 
			"team_id", user.TeamId, 
			"score_added", p.Score,
		)
	}
	return nil
}
