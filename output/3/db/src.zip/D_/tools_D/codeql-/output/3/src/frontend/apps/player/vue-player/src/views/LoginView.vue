<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { login, register } from "@shared-api/services";
import { saveSession } from "@shared-api/http";

const router = useRouter();
const mode = ref("login");
const form = ref({ username: "", email: "", password: "", confirmPassword: "" });
const message = ref("");
const error = ref(false);

function toast(text, isError = false) {
  message.value = text;
  error.value = isError;
}

async function onLogin() {
  try {
    const result = await login({ username: form.value.username.trim(), password: form.value.password });
    saveSession(result.data?.token, result.data?.user);
    router.push("/home");
  } catch (e) {
    toast(e.message || "登录失败", true);
  }
}

async function onRegister() {
  if (form.value.password !== form.value.confirmPassword) {
    toast("两次密码不一致", true);
    return;
  }
  try {
    await register({
      username: form.value.username.trim(),
      email: form.value.email.trim(),
      password: form.value.password,
    });
    toast("注册成功，请登录");
    mode.value = "login";
  } catch (e) {
    toast(e.message || "注册失败", true);
  }
}
</script>

<template>
  <div class="page center">
    <div class="login-shell">
      <header class="login-head">
        <a class="back-link" @click.prevent="router.push('/home')" href="#">返回比赛首页</a>
        <h1>账号中心</h1>
        <p>在这里完成登录、注册与会话管理</p>
      </header>

      <div class="card auth">
      <h2>CTF 平台登录</h2>
      <div class="tabs">
        <button :class="{ active: mode === 'login' }" @click="mode = 'login'">登录</button>
        <button :class="{ active: mode === 'register' }" @click="mode = 'register'">注册</button>
      </div>

      <div class="form">
        <input v-model="form.username" placeholder="用户名" />
        <input v-if="mode === 'register'" v-model="form.email" placeholder="邮箱" />
        <input v-model="form.password" type="password" placeholder="密码" />
        <input
          v-if="mode === 'register'"
          v-model="form.confirmPassword"
          type="password"
          placeholder="确认密码"
        />

        <button v-if="mode === 'login'" @click="onLogin">登录</button>
        <button v-else @click="onRegister">注册</button>
      </div>

      <p v-if="message" :class="['hint', error ? 'err' : 'ok']">{{ message }}</p>
      <p class="note">登录后才能访问比赛大厅、题目、队伍和设置页面。</p>
      </div>
    </div>
  </div>
</template>
