package config

import (
	"errors"
	"fmt"
	"os"

	"backend/model"
	"backend/util"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var DB *gorm.DB

type DBConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	DBName   string
}

func InitDBConfig() *DBConfig {
	return &DBConfig{
		Host:     os.Getenv("DB_HOST"),
		Port:     os.Getenv("DB_PORT"),
		User:     os.Getenv("DB_USER"),
		Password: os.Getenv("DB_PASSWORD"),
		DBName:   os.Getenv("DB_NAME"),
	}
}

func GetEnv(key string) string {
	value := os.Getenv(key)
	if value == "" {
		panic(fmt.Sprintf("环境变量 %s 未设置", key))
	}
	return value
}

func InitDB(config *DBConfig) (*gorm.DB, error) {

	dsn := fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		config.Host, config.Port, config.User, config.Password, config.DBName,
	)

	DB, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		return nil, fmt.Errorf("数据库初始化连接失败: %w", err)
	}

	// 自动迁移数据库结构
	err = DB.AutoMigrate(
		&model.User{},
		&model.Team{},
		// &model.TokenBlacklist{},
		&model.Games{},
		&model.Challenge{},
		&model.Solve{},
		&model.Submissions{},
		&model.ContainerInstance{},
	)
	// 添加管理员用户（仅在不存在 admin 用户时创建）
	var admin model.User
	if err := DB.Where("username = ?", "admin").First(&admin).Error; errors.Is(err, gorm.ErrRecordNotFound) {
		// 读取管理员密码环境变量，默认回退到 "admin123"
		adminPassword := os.Getenv("ADMIN_PASSWORD")
		if adminPassword == "" {
			adminPassword = "admin123"
		}
		pwdHash, err := bcrypt.GenerateFromPassword([]byte(adminPassword), bcrypt.DefaultCost)
		if err != nil {
			return nil, fmt.Errorf("生成管理员密码哈希失败: %w", err)
		}

		adminEmail := os.Getenv("ADMIN_EMAIL")
		if adminEmail == "" {
			adminEmail = "admin@example.com"
		}

		if err := DB.Create(&model.User{
			UserId:       util.GenerateHashID("admin"), 
			Username:     "admin",
			Email:        adminEmail,
			PasswordHash: string(pwdHash),
			Role:         "admin",
		}).Error; err != nil {
			return nil, fmt.Errorf("初始化管理员用户失败: %w", err)
		}
	} else if err != nil {
		return nil, fmt.Errorf("查询管理员用户失败: %w", err)
	}

	if err != nil {
		return nil, fmt.Errorf("数据库自动迁移失败: %w", err)
	}
	return DB, nil
}
