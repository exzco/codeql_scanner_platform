<script setup>
import { onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import AppShell from "@shared-ui/components/AppShell.vue";
import { changePassword, getProfile, logout } from "@shared-api/services";
import { clearSession } from "@shared-api/http";

const router = useRouter();
const profile = ref({});
const oldPassword = ref("");
const newPassword = ref("");
const confirmPassword = ref("");
const message = ref("");

async function load() {
  try {
    const result = await getProfile();
    profile.value = result.data || {};
  } catch (e) {
    message.value = e.message || "获取用户信息失败";
  }
}

async function onChangePassword() {
  if (newPassword.value.length < 8) {
    message.value = "新密码至少 8 位";
    return;
  }
  if (newPassword.value !== confirmPassword.value) {
    message.value = "两次新密码不一致";
    return;
  }

  try {
    const result = await changePassword({ oldPassword: oldPassword.value, newPassword: newPassword.value });
    message.value = result.message || "修改成功";
    oldPassword.value = "";
    newPassword.value = "";
    confirmPassword.value = "";
  } catch (e) {
    message.value = e.message || "修改失败";
  }
}

async function onLogout() {
  try {
    await logout();
  } catch {
    // ignore
  }
  clearSession();
  router.push("/login");
}

onMounted(load);
</script>

<template>
  <AppShell title="设置">
    <template #actions>
      <button @click="router.push('/home')">返回大厅</button>
      <button @click="onLogout">退出登录</button>
    </template>

    <div class="layout layout-2">
      <main class="card detail">
        <h3>个人信息</h3>
        <p>用户名: {{ profile.username }}</p>
        <p>邮箱: {{ profile.email }}</p>
        <p>角色: {{ profile.role }}</p>
        <p>UID: {{ profile.id }}</p>
      </main>

      <aside class="card list">
        <h3>修改密码</h3>
        <input v-model="oldPassword" type="password" placeholder="旧密码" />
        <input v-model="newPassword" type="password" placeholder="新密码" />
        <input v-model="confirmPassword" type="password" placeholder="确认新密码" />
        <button @click="onChangePassword">提交修改</button>
        <p class="hint">{{ message }}</p>
      </aside>
    </div>
  </AppShell>
</template>
