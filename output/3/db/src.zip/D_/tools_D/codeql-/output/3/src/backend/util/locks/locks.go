package locks

import (
	"backend/config"
	"context"
	"time"
)

// 获取分布式锁
func TryLock(ctx context.Context, key string, expiration time.Duration) (bool, error) {
	if config.RDB == nil {
		return false, nil
	}
	return config.RDB.SetNX(ctx, key, 1, expiration).Result()
}

// 释放分布式锁
func ReleaseLock(ctx context.Context, key string) error {
	if config.RDB == nil {
		return nil
	}
	return config.RDB.Del(ctx, key).Err()
}
