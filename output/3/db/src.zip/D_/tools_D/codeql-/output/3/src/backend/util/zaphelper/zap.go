package zaphelper

import (
	"os"

	"github.com/fatih/color"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

// 消息队列日志 

var Logger *zap.Logger
var Sugar *zap.SugaredLogger

func coloredLevelEncoder(level zapcore.Level, enc zapcore.PrimitiveArrayEncoder) {
	switch level {
	case zapcore.DebugLevel:
		enc.AppendString(color.CyanString(level.String()))
	case zapcore.InfoLevel:
		enc.AppendString(color.GreenString(level.String()))
	case zapcore.WarnLevel:
		enc.AppendString(color.YellowString(level.String()))
	case zapcore.ErrorLevel:
		enc.AppendString(color.RedString(level.String()))
	default:
		enc.AppendString(level.String())
	}
}

func getConsoleCore() zapcore.Core {
	config := zap.NewDevelopmentEncoderConfig()
	config.EncodeLevel = coloredLevelEncoder
	config.EncodeTime = zapcore.ISO8601TimeEncoder
	config.FunctionKey = "func"
	encoder := zapcore.NewConsoleEncoder(config)
	writer := zapcore.Lock(os.Stdout)
	return zapcore.NewCore(encoder, writer, zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl >= zapcore.DebugLevel
	}))
}

func getFileCore() zapcore.Core {
	dailyWriter := newDailyRotateWriter("./logs", "backend_", ".log")
	config := zap.NewProductionEncoderConfig()
	config.EncodeTime = zapcore.ISO8601TimeEncoder
	encoder := zapcore.NewJSONEncoder(config)
	writer := zapcore.AddSync(dailyWriter)
	return zapcore.NewCore(encoder, writer, zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
		return lvl >= zapcore.InfoLevel
	}))
}

func InitZap() {
	core := zapcore.NewTee(getConsoleCore(), getFileCore())
	tmpLogger := zap.New(core, zap.AddCaller())
	Logger = tmpLogger
	Sugar = tmpLogger.Sugar()
}

func CloseZap() {
	if Sugar != nil {
		_ = Sugar.Sync()
	}
}
