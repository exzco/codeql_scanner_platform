package model

import "time"

type ContainerInstance struct {
	InstanceId  string    `gorm:"primaryKey;type:varchar(64)"`             // UUID
	UserId      string    `gorm:"not null"`                                // The user who started this
	TeamId      string                                                     // If the challenge is started for a team
	ChallengeId string    `gorm:"not null"`                                // Which challenge this is
	GameId      string    `gorm:"not null"`                                // Associated Game
	Namespace   string    `gorm:"type:varchar(64);not null"`               //  k8s 命名空间
	PodName     string    `gorm:"type:varchar(128);uniqueIndex;not null"`  // e.g. "chal-1-user-2"
	ServicePort int32                                                      // The port assigned (if using NodePort, otherwise 80 internal)
	DynamicFlag string    `gorm:"type:varchar(64);not null"`               // The dynamically generated flag
	Status      string    `gorm:"type:varchar(32);"`      // "pending", "running", "expired"，"error"
	ExpiresAt   time.Time                                                  // When this container should be destroyed automatically
	CreatedAt   time.Time `gorm:"autoCreateTime"`
}

type AdminContainerOperationReq struct {
	InstanceId string `json:"instanceId" binding:"required"`
}