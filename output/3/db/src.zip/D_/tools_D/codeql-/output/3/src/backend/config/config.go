package config

var JWTSecretKey string
var FlagPrefix string = "JNCTF"
var FlagSalt string = "salt_2026"
var ChalDomain string = "ctf.local.com"
