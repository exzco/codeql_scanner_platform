package zaphelper

import (
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type dailyRotateWriter struct {
	mu       sync.Mutex
	file     *os.File
	filePath string
	prefix   string
	suffix   string
	lastDate string
}

func newDailyRotateWriter(dir, prefix, suffix string) *dailyRotateWriter {
	if err := os.MkdirAll(dir, 0755); err != nil {
		panic(err)
	}

	w := &dailyRotateWriter{
		filePath: dir,
		prefix:   prefix,
		suffix:   suffix,
		lastDate: time.Now().Format("2006-01-02"),
	}

	w.rotateIfNeeded()
	return w
}

func (w *dailyRotateWriter) Write(p []byte) (n int, err error) {
	w.mu.Lock()
	defer w.mu.Unlock()

	if err := w.rotateIfNeeded(); err != nil {
		return 0, err
	}

	return w.file.Write(p)
}

func (w *dailyRotateWriter) Sync() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.file != nil {
		return w.file.Sync()
	}
	return nil
}

func (w *dailyRotateWriter) rotateIfNeeded() error {
	now := time.Now()
	currentDate := now.Format("2006-01-02")

	if currentDate == w.lastDate && w.file != nil {
		return nil
	}

	if w.file != nil {
		_ = w.file.Close()
	}

	w.lastDate = currentDate
	logFile := filepath.Join(w.filePath, fmt.Sprintf("%s%s%s", w.prefix, now.Format("2006-01-02"), w.suffix))

	var err error
	w.file, err = os.OpenFile(logFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	return err
}
