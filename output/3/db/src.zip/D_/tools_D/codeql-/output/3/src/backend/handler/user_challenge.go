package handler

import (
	"backend/config"
	"backend/model"
	"fmt"
	"log"
	"net/http"
	"time"

	"backend/async_tasks"
	"backend/util"
	"backend/util/locks"
	"crypto/md5"
	"encoding/hex"

	"github.com/gin-gonic/gin"
)

// @summary 获取比赛题目列表
// @tags 题目接口
// @param id path int true "比赛ID"
// @success 200 {object} gin.H "返回题目列表"
// @router /api/auth/games/{id}/challenges [get]
func GetChallenges(c *gin.Context) {
	gameId := c.Param("id")

	var challenges []model.Challenge
	if err := config.DB.Where("game_id = ?", gameId).Find(&challenges).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "获取题目列表失败"})
		return
	}

	// 获取用户提交的解题记录，判断用户解出了哪些题目,然后构造响应数据发送到前端
	var challengeResponses []model.ChallengeResponse
	for i := range challenges {
		var solve model.Solve
		userId := c.GetString("UserId")
		challengeId := challenges[i].ChallengeId
		// 题目id 比赛id 用户id 确定是否解出这场比赛的这个题目
		if err := config.DB.Where("user_id = ? AND challenge_id = ? AND game_id = ?", userId, challengeId, gameId).First(&solve).Error; err == nil {
			challengeResponses = append(challengeResponses, model.ChallengeResponse{
				ChallengeId: challenges[i].ChallengeId,
				GameId:      challenges[i].GameId,
				Title:       challenges[i].Title,
				Category:    challenges[i].Category,
				Score:       challenges[i].Score,
				Difficulty:  challenges[i].Difficulty,
				IsStatic:    challenges[i].IsStatic != nil && *challenges[i].IsStatic,
				IsSolved:    true,
			})
		} else {
			challengeResponses = append(challengeResponses, model.ChallengeResponse{
				ChallengeId: challenges[i].ChallengeId,
				GameId:      challenges[i].GameId,
				Title:       challenges[i].Title,
				Category:    challenges[i].Category,
				Score:       challenges[i].Score,
				Difficulty:  challenges[i].Difficulty,
				IsStatic:    challenges[i].IsStatic != nil && *challenges[i].IsStatic,
				IsSolved:    false,
			})
		}
	}

	log.Printf("Retrieved challenges: %v", challengeResponses)
	c.JSON(http.StatusOK, gin.H{"message": "success", "data": challengeResponses})
}

// @summary 提交题目 flag
// @tags 题目接口
// @param id path string true "比赛ID"
// @param challengeId path string true "题目ID"
// @param model.SubmitFlagRequest
// @success 200 {object} gin.H "返回提交结果"
// @router /api/auth/games/{id}/challenges/{challengeId}/submit [post]
func SubmitFlag(c *gin.Context) {
	// 上下文自带 UserId ,中间件那块的东西 c.Set("UserId")
	UserId := c.GetString("UserId")
	gameId := c.Param("id")
	challengeId := c.Param("challengeId")
	var req model.SubmitFlagRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.challenge.SubmitFlag_1"})
		return
	}

	// 校验比赛是否存在
	var game model.Games
	if err := config.DB.Where("game_id = ?", gameId).First(&game).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.challenge.SubmitFlag_2"})
		return
	}

	// 验证题目是否存在
	var challenge model.Challenge
	if err := config.DB.Where("challenge_id = ? AND game_id = ?", challengeId, gameId).First(&challenge).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.challenge.SubmitFlag_3"})
		return
	}

	// 校验是否在比赛时间内
	if game.StartTime.After(util.Now()) || game.EndTime.Before(util.Now()) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "当前不在比赛时间内，无法提交", "position": "handler.challenge.SubmitFlag_4"})
		return
	}

	// 如果是动态题目，需要调用 k8s 接口验证 flag
	if challenge.IsStatic != nil && !*challenge.IsStatic {
		var container model.ContainerInstance
		if err := config.DB.Where("user_id = ? AND challenge_id = ? AND game_id = ? AND status = ?", UserId, challengeId, gameId, "running").First(&container).Error; err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "你必须先启动题目容器才能提交动态 Flag", "position": "handler.challenge.SubmitFlag_4"})
			return
		}

		if container.DynamicFlag != req.Flag {
			c.JSON(http.StatusOK, gin.H{"message": "动态 flag 错误 (注意每个人拥有专属的Flag哦)"})
			return
		}
	} else {
		// 验证提交的 flag 是否正确（静态 flag）
		if challenge.Flag != req.Flag {
			c.JSON(http.StatusOK, gin.H{"message": "flag 错误"})
			return
		}
	}

	// 存储提交记录（利用唯一索引阻挡重复交flag并发）
	solve := model.Solve{
		UserId:       UserId,
		ChallengeId:  challenge.ChallengeId,
		GameId:       challenge.GameId,
		SolvedAtTime: util.Now(),
		Score:        challenge.Score,
	}

	if err := config.DB.Create(&solve).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "您已经解答过该题或者遇到了异常：" + err.Error()})
		return
	}

	// 解除繁重的同步事务，将计分逻辑和排位刷新直接丢进 MQ 异步慢慢算
	_ = async_tasks.EnqueueSyncScore(async_tasks.ScoreTaskPayload{
		UserId:      UserId,
		ChallengeId: challenge.ChallengeId,
		GameId:      challenge.GameId,
		Score:       challenge.Score,
	})

	// 返回提交结果，极速响应，无需等待排行榜重算
	c.JSON(http.StatusOK, gin.H{"message": "flag 正确，提交成功，积分将在后台计算刷新！"})

}

// @summary 启动题目容器
// @router /api/auth/games/{id}/challenges/{challengeId}/start [post]
func StartChallengeContainer(c *gin.Context) {

	userId := c.GetString("UserId")
	gameId := c.Param("id")
	challengeId := c.Param("challengeId")

	// 0. 限制短时间内重复请求
	lockKey := fmt.Sprintf("lock:start_container:u%s_c%s", userId, challengeId)
	locked, err := locks.TryLock(c.Request.Context(), lockKey, 10*time.Second)
	if err != nil || !locked {
		c.JSON(http.StatusTooManyRequests, gin.H{"error": "请求过于频繁，请稍后再试"})
		return
	}

	// 1. 检查是否存在已经 Running 的容器
	var existContainer model.ContainerInstance
	if err := config.DB.Where("user_id = ? AND challenge_id = ? AND game_id = ? AND status = ?", userId, challengeId, gameId, "running").First(&existContainer).Error; err == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "你已经启动了该题目的容器，请先销毁之前的容器，才能重新启动。"})
		return
	}

	// 2. 查询题目详细信息
	var challenge model.Challenge
	if err := config.DB.Where("challenge_id = ? AND game_id = ?", challengeId, gameId).First(&challenge).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "题目未找到"})
		return
	}

	if challenge.IsStatic != nil && *challenge.IsStatic {
		c.JSON(http.StatusBadRequest, gin.H{"error": "该题目为静态题目，不需要启动独立靶机环境"})
		return
	}

	// 3. 查询用户所在队伍 (必须已加入队伍才能启动靶机)
	var user model.User
	if err := config.DB.Where("user_id = ?", userId).First(&user).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "查询用户信息失败"})
		return
	}
	if user.TeamId == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "请先加入或创建一个战队，才能启动靶机"})
		return
	}
	teamId := *user.TeamId

	// Salt + TeamID + UserID + ChallengeID + NanoTime
	rawFlag := fmt.Sprintf("%s-%s-%s-%s-%d", config.FlagSalt, teamId, userId, challenge.ChallengeId, time.Now().UnixNano())
	hash := md5.Sum([]byte(rawFlag))
	dynamicFlag := fmt.Sprintf("%s{%s}", config.FlagPrefix, hex.EncodeToString(hash[:]))

	instanceId := fmt.Sprintf("u%sc%st%d", userId, challenge.ChallengeId, time.Now().Unix())

	// 读取绑定的镜像名
	imageName := challenge.ImageName

	// 4. 为每个团队一个分配专属的独立 Namespace
	userNamespace := fmt.Sprintf("jn-t%s", teamId)
	// subdomain := fmt.Sprintf("chal-%s.%s", instanceId, config.ChalDomain)
	// 题目 url
	url_ := fmt.Sprintf("http://chal-%s.%s", instanceId,config.ChalDomain)

	// 5. 将 status 置为 pending
	newContainer := model.ContainerInstance{
		InstanceId:  instanceId,
		UserId:      userId,
		TeamId:      teamId,
		ChallengeId: challenge.ChallengeId,
		GameId:      challenge.GameId,
		Namespace:   userNamespace,
		PodName:     fmt.Sprintf("chal-%s", instanceId),
		DynamicFlag: dynamicFlag,
		Status:      "pending",                     // 等待消费者接单创建 K8s 资源
		ExpiresAt:   time.Now().Add(2 * time.Hour), // 默认2小时生命周期
	}

	if err := config.DB.Create(&newContainer).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "写入数据库记录失败"})
		return
	}

	// 6. 将创建动作发送至 Redis 消息队列
	if err := async_tasks.EnqueueStartContainer(async_tasks.ContainerTaskPayload{
		InstanceId:    instanceId,
		UserId:        userId,
		TeamId:        teamId,
		ChallengeId:   challenge.ChallengeId,
		GameId:        challenge.GameId,
		Namespace:     userNamespace,
		ImageName:     imageName,
		NeedHostMount: challenge.NeedHostMount,
		DynamicFlag:   dynamicFlag,
		ContainerPort: challenge.ContainerPort,
	}); err != nil {
		config.DB.Delete(&newContainer)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建容器失败，请稍后再试", "detail": err.Error()})
		return
	}

	// 成功响应 前端转圈加载，等待获取最终状态
	c.JSON(http.StatusOK, gin.H{
		"message": "容器正在启动",
		"data": gin.H{
			"url":        url_,
			"expires_at": newContainer.ExpiresAt,
		},
	})
}

// @summary 延长容器生命周期
// @tags 题目管理
// @router /api/auth/games/{id}/challenges/{challengeId}/extend [post]
func ExtendChallengeContainer(c *gin.Context) {
	userId := c.GetString("UserId") // 和中间件 c.Set("UserId") 保持一致
	gameId := c.Param("id")
	challengeId := c.Param("challengeId")

	//  加锁
	lockKey := fmt.Sprintf("lock:extend_container:u%s_c%s", userId, challengeId)
	locked, err := locks.TryLock(c.Request.Context(), lockKey, 10*time.Second)
	if err != nil || !locked {
		c.JSON(http.StatusTooManyRequests, gin.H{"error": "请勿重复点击，请稍后再试"})
		return
	}

	//  查找属于该用户的、正在运行的容器
	var container model.ContainerInstance
	if err := config.DB.Where("user_id = ? AND challenge_id = ? AND game_id = ? AND status = ?",
		userId, challengeId, gameId, "running").First(&container).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "没有找到属于你运行中的环境容器"})
		return
	}

	//  剩余时间大于 1 小时不得续期
	if container.ExpiresAt.Sub(time.Now()) > time.Hour {
		c.JSON(http.StatusBadRequest, gin.H{"error": "容器生命周期剩余大于一小时，暂无法延长"})
		return
	}
	newExpiry := container.ExpiresAt.Add(time.Hour)

	//  更新数据库
	if err := config.DB.Model(&container).Update("expires_at", newExpiry).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "延长靶机时间操作失败"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":        "延长靶机生命周期成功",
		"new_expires_at": newExpiry,
		"remaining_mins": int(newExpiry.Sub(time.Now()).Minutes()),
	})
}

// @summary 销毁题目容器
// @router /api/auth/games/{id}/challenges/{challengeId}/destroy [post]
func DestroyChallengeContainer(c *gin.Context) {
	userId := c.GetString("UserId") // 和中间件 c.Set("UserId") 保持一致
	gameId := c.Param("id")
	challengeId := c.Param("challengeId")

	var container model.ContainerInstance
	err := config.DB.Where("user_id = ? AND challenge_id = ? AND game_id = ? AND status IN ?",
		userId, challengeId, gameId, []string{"running", "pending"}).First(&container).Error
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "未发现正在运行的靶机容器"})
		return
	}

	// 置为过渡态，然后往队列中投递销毁单
	config.DB.Model(&container).Update("status", "stopping")
	err = async_tasks.EnqueueStopContainer(async_tasks.ContainerTaskPayload{
		InstanceId: container.InstanceId,
		Namespace:  container.Namespace,
	})

	if err != nil {
		// 回滚过渡态，避免容器卡在 stopping 状态永远出不来
		config.DB.Model(&container).Update("status", "running")
		c.JSON(http.StatusInternalServerError, gin.H{"error": "销毁请求入队失败"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "靶机容器销毁请求已提交，正在异步处理中"})
}
