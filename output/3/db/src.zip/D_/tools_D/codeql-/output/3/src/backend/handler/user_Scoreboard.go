package handler

import (
	"backend/config"
	"backend/model"
	"github.com/gin-gonic/gin"
	"net/http"
)

// @summary 获取团队得分数据，用于排行榜
// @tags 排行榜接口
// @success 200 {object} gin.H "返回排行榜数据"
// @router /api/auth/scoreboard [get]
func GetScoreboard(c *gin.Context) {

	// 1. 优先从 redis sorted set 获取排行榜数据
	results, err := config.RDB.ZRevRangeWithScores(config.Ctx, "scoreboard", 0, -1).Result()
	results_count := len(results)
	if err == nil && results_count > 0 {
		data := make([]model.Rank, results_count)
		for i, j := range results {
			data[i] = model.Rank{
				Rank:     i + 1,
				TeamName: j.Member.(string),
				Score:    j.Score,
			}
		}
		c.JSON(http.StatusOK, gin.H{
			"message": "获取排行榜数据成功",
			"data":    data,
		})
		return
	}

	// 2. 如果 redis 数据为空或查询失败，从数据库查询
	var teams []model.Team
	if err := config.DB.Order("score desc").Find(&teams).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"message": "获取排行榜数据失败",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "获取排行榜数据成功",
		"data":    teams,
	})

}
