package handler

import (
	"backend/config"
	"backend/model"
	"backend/util"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
	"time"
	
)

// position 调试使用，定位错误点

// @Summary 用户注册
// @Tags 用户接口
// @Param   username body string true "用户名"
// @Param   password body string true "密码"
// @Param   email    body string true "邮箱"
// @Success 200 {object} gin.H
// @Router /api/public/register [post]
func Register(c *gin.Context) {
	var req model.RegisterRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": err.Error(), "poisition": "handler.Register_1"})
		return
	}
	if req.Username == "admin" {
		c.JSON(400, gin.H{"error": "admin 用户已存在"})
		return
	}
	var exist model.User
	if err := config.DB.Where("username = ? OR email = ?", req.Username, req.Email).First(&exist).Error; err == nil {
		c.JSON(400, gin.H{"error": "username or email already exists"})
		return
	}

	passwordHash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		c.JSON(500, gin.H{"error": "failed to hash password"})
		return
	}

	user := model.User{
		UserId:       util.GenerateHashID(req.Username),
		Username:     req.Username,
		Email:        req.Email,
		PasswordHash: string(passwordHash),
		Role:         "user",
	}

	if err := config.DB.Create(&user).Error; err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{"message": "注册成功", "data": gin.H{"user_id": user.UserId}})
}

// @Summary 用户登录
// @Tags 用户接口
// @Param   username body string true "用户名"
// @Param   password body string true "密码"
// @Success 200 {object} model.User "返回用户信息"
// @Router /api/public/login [post]
func Login(c *gin.Context) {
	var req model.LoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	var user model.User
	if err := config.DB.Where("username = ?", req.Username).First(&user).Error; err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)); err != nil {
		c.JSON(400, gin.H{"error": "账号或者密码错误，请重新输入"})
		return
	}

	token, err := util.GenerateToken(&user, config.JWTSecretKey)
	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{"message": "登录成功", "data": gin.H{"token": token, "user": gin.H{
		"id":       user.UserId,
		"username": user.Username,
		"role":     user.Role,
	},
	},
	})
}

// @Summary 用户登出
// @Tags 用户接口
// @Security ApiKeyAuth
// @Success 200 {object} gin.H
// @Router /api/auth/logout [post]
func Logout(c *gin.Context) {
	// 1. 获取 token
	tokenString, err := util.ExtractToken(c.GetHeader("Authorization"))
	if err != nil {
		c.JSON(401, gin.H{"error": err.Error()})
		return
	}

	// 2. 获取上下文中的 claims
	claimsVal, exists := c.Get("claims")
	if !exists {
		c.JSON(401, gin.H{"error": "claims not found in context"})
		return
	}

	claims, ok := claimsVal.(*model.Claims)
	if !ok {
		c.JSON(401, gin.H{"error": "invalid claims type"})
		return
	}

	// 3. 验证用户是否存在
	var user model.User
	if err := config.DB.Where("id = ?", claims.UserId).First(&user).Error; err != nil {
		c.JSON(401, gin.H{"error": err.Error()})
		return
	}

	// 4. 把 Token 存入黑名单
	expireTime := claims.ExpiresAt.Time 
	ttl := time.Until(expireTime)
	if ttl <= 0 {
		// token 已经过期
		c.JSON(200,gin.H{"message":"登出成功"})
		return
	}

	err = config.RDB.Set(config.Ctx,"tokenBlackList:"+tokenString,"1",ttl).Err()
	if err != nil {
		c.JSON(500,gin.H{"error":"登出失败,请重试"})
		return
	}

	c.JSON(200, gin.H{"message": "登出成功"})
}

// @summary 获取个人信息
// @tags 用户接口
// @Security ApiKeyAuth
// @Success 200 {object} gin.H "返回个人信息"
// @Router /api/auth/user/profile [get]
func GetProfile(c *gin.Context) {
	claimsVal, exists := c.Get("claims")
	if !exists {
		c.JSON(401, gin.H{"error": "claims not found in context"})
		return
	}

	claims, ok := claimsVal.(*model.Claims)
	if !ok {
		c.JSON(401, gin.H{"error": "invalid claims type"})
		return
	}

	var user model.User
	if err := config.DB.Where("user_id = ?", claims.UserId).First(&user).Error; err != nil {
		c.JSON(401, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{"message": "获取个人信息成功", "data": gin.H{
		"id":       user.UserId,
		"username": user.Username,
		"email":    user.Email,
		"role":     user.Role,
		"teamId":   user.TeamId,
	},
	})
}

// @summary 修改密码
// @tags 用户接口
// @Security ApiKeyAuth
// @Success 200 {object} gin.H "返回修改结果"
// @Router /api/auth/user/profile/ChangePassword [post]
func ChangePassword(c *gin.Context) {
	claimsVal, exists := c.Get("claims")
	if !exists {
		c.JSON(401, gin.H{"error": "claims not found in context"})
		return
	}

	claims, ok := claimsVal.(*model.Claims)
	if !ok {
		c.JSON(401, gin.H{"error": "invalid claims type"})
		return
	}

	var user model.User
	if err := config.DB.Where("user_id = ?", claims.UserId).First(&user).Error; err != nil {
		c.JSON(401, gin.H{"error": err.Error()})
		return
	}

	var req model.ChangePasswordRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.OldPassword)); err != nil {
		c.JSON(400, gin.H{"error": "旧密码错误"})
		return
	}

	passwordHash, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		c.JSON(500, gin.H{"error": "failed to hash password"})
		return
	}

	if err := config.DB.Model(&user).Update("password_hash", string(passwordHash)).Error; err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{"message": "修改密码成功"})
}


