<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { login } from "@shared-api/services";
import { saveSession } from "@shared-api/http";

const router = useRouter();
const username = ref("");
const password = ref("");
const message = ref("");

async function onLogin() {
  message.value = "";
  try {
    const result = await login({ username: username.value.trim(), password: password.value });
    const token = result?.data?.token;
    const user = result?.data?.user || {};

    if (!token) {
      throw new Error("登录返回缺少 token");
    }
    if (user.role !== "admin") {
      throw new Error("当前账号不是管理员，无法进入 admin 页面");
    }

    saveSession(token, user);
    router.push("/admin");
  } catch (error) {
    message.value = error.message || "登录失败";
  }
}
</script>

<template>
  <div class="page center">
    <div class="login-shell">
      <header class="login-head">
        <h1>管理后台</h1>
        <p>请输入管理员账号登录</p>
      </header>

      <div class="card auth-card">
        <label>用户名</label>
        <input v-model="username" placeholder="admin" />
        <label>密码</label>
        <input v-model="password" type="password" placeholder="请输入密码" />
        <button @click="onLogin">登录管理后台</button>
        <p class="hint err" v-if="message">{{ message }}</p>
      </div>
    </div>
  </div>
</template>
