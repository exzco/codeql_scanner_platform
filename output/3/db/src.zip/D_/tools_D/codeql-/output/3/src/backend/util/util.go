package util

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"math/big"
	"time"

	"github.com/lib/pq"
)

func Now() time.Time {
	return time.Now()
}

func GenerateInviteCode() string {
	const charset = "ABCDEFGHGKMNPQRSTUVWXYZ23456789"
	code := make([]byte, 8)
	for i := range code {
		n, _ := rand.Int(rand.Reader, big.NewInt(int64(len(charset))))
		code[i] = charset[n.Int64()]
	}
	return string(code)
}

func GenerateHashID(seed string) string {
	h := sha256.New()
	h.Write([]byte(seed + fmt.Sprintf("%d", time.Now().UnixNano())))
	return hex.EncodeToString(h.Sum(nil))[:8]
}

func GenerateTeamId(teamName string) string {
	return GenerateHashID(teamName)
}



// 处理 PostgreSQL 字符串数组的移除逻辑
func Remove(slice pq.StringArray, target string) pq.StringArray {
	for i, v := range slice {
		if v == target {
			return append(slice[:i], slice[i+1:]...)
		}
	}
	return slice
}
