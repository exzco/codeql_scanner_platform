package handler

import (
	"backend/async_tasks"
	"backend/config"
	"backend/model"
	"net/http"

	"github.com/gin-gonic/gin"
)

// @summary 管理员获取所有动态容器列表
// @tags 容器管理
// @router /api/auth/admin/containerList [post]
func AdminListContainers(c *gin.Context) {
	var containers []model.ContainerInstance
	
	// 这里可以加入按比赛ID、题目ID搜索的逻辑
	if err := config.DB.Order("created_at desc").Find(&containers).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "获取容器列表失败", "detail": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"code": 200, "data": containers})
}



// @summary 管理员强制销毁容器
// @tags 容器管理
// @param AdminContainerOperationReq
// @router /api/auth/admin/containerDelete [post]
func AdminDeleteContainer(c *gin.Context) {
	var req model.AdminContainerOperationReq
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var container model.ContainerInstance
	if err := config.DB.Where("instance_id = ?", req.InstanceId).First(&container).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "容器记录未找到"})
		return
	}

	// 往消息队列投递销毁命令
	err := async_tasks.EnqueueStopContainer(async_tasks.ContainerTaskPayload{
		InstanceId: container.InstanceId,
		Namespace:  container.Namespace,
	})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "放入删除队列失败"})
		return
	}
	
	config.DB.Model(&container).Update("status", "stopping")
	c.JSON(http.StatusOK, gin.H{"code": 200, "message": "已成功投递强制销毁指命"})
}