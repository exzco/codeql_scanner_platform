<script setup>
import { onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import AppShell from "@shared-ui/components/AppShell.vue";
import { getScoreboard, getTeamInfo, leaveTeam } from "@shared-api/services";

const router = useRouter();
const team = ref(null);
const members = ref([]);
const rankText = ref("-");
const message = ref("");

async function load() {
  try {
    const res = await getTeamInfo();
    team.value = res.data || {};
    members.value = Array.isArray(team.value.members) ? team.value.members : [];

    const rankRes = await getScoreboard();
    const rows = Array.isArray(rankRes.data) ? rankRes.data : [];
    const row = rows.find((x) => String(x.teamName) === String(team.value.teamName));
    rankText.value = row ? `#${row.rank}` : "-";
  } catch (e) {
    message.value = e.message || "加载队伍失败";
  }
}

async function onLeave() {
  try {
    await leaveTeam();
    router.push("/home");
  } catch (e) {
    message.value = e.message || "退出队伍失败";
  }
}

onMounted(load);
</script>

<template>
  <AppShell title="队伍管理">
    <template #actions>
      <button @click="router.push('/home')">返回大厅</button>
    </template>

    <div class="layout layout-2">
      <main class="card detail" v-if="team">
        <h3>{{ team.teamName }}</h3>
        <p>队伍分数: {{ team.score }}</p>
        <p>当前排名: {{ rankText }}</p>
        <p v-if="team.inviteCode">邀请码: {{ team.inviteCode }}</p>
        <button @click="onLeave">退出队伍</button>
        <p class="hint">{{ message }}</p>
      </main>

      <aside class="card list">
        <h3>成员列表</h3>
        <p v-for="m in members" :key="m.userId">{{ m.username }} / score: {{ m.score }}</p>
      </aside>
    </div>
  </AppShell>
</template>
