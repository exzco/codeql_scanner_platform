package middleware

import (
	"backend/config"
	"backend/model"
	"backend/util"
	"backend/util/zaphelper"
	"fmt"
	"net/http"
	"sync"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"golang.org/x/time/rate"
)

// CORS 解决跨域问题
func CORS() gin.HandlerFunc {
	config := cors.Config{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"GET", "POST", "OPTIONS"},
		AllowHeaders:     []string{"*"},
		ExposeHeaders:    []string{"*"},
		AllowCredentials: true,
	}
	return cors.New(config)
}

// AuthMiddleware 验证 JWT token
func AuthMiddleware(secretKey string) gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString, err := util.ExtractToken(c.GetHeader("Authorization"))
		if err != nil {
			c.JSON(401, gin.H{"error": "authorization header is required"})
			c.Abort()
			return
		}

		// 从 Redis 检查 token 是否在黑名单中
		exists, err := config.RDB.Exists(config.Ctx, "tokenBlackList:"+tokenString).Result()
		if err == nil && exists > 0 {
			c.JSON(401, gin.H{"error": "token has been logged out"})
			c.Abort()
			return
		}

		claims, err := util.InspectionToken(tokenString, secretKey)
		if err != nil {
			prefix := tokenString
			zaphelper.Sugar.Warnw("JWT 鉴权失败", "error", err, "token_prefix", prefix)
			c.JSON(http.StatusUnauthorized, gin.H{"error": "无效或过期的令牌", "detail": err.Error()})
			c.Abort()
			return
		}
		c.Set("UserId", claims.UserId)
		c.Set("claims", claims)
		c.Next()
		
	}
}

// AdminAuthMiddleware 验证管理员权限
func AdminAuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		claimsVal, exists := c.Get("claims")
		if !exists {
			c.JSON(401, gin.H{"error": "claims not found in context"})
			c.Abort()
			return
		}

		claims, ok := claimsVal.(*model.Claims)
		if !ok {
			c.JSON(401, gin.H{"error": "invalid claims type"})
			c.Abort()
			return
		}

		if claims.Role != "admin" {
			c.JSON(403, gin.H{"error": "admin access required"})
			c.Abort()
			return
		}

		c.Next()
	}
}

// RateLimiter 令牌桶限流中间件
// rateLimit: 桶容量（最大突发请求数）
// tokenInterval: 每隔多久补充一个令牌
func RateLimiter(rateLimit int, tokenInterval time.Duration) gin.HandlerFunc {
	type limiterInfo struct {
		limiter  *rate.Limiter
		lastUsed time.Time
	}

	limiters := sync.Map{}

	// 每小时删除不活跃的限速器，防止内存泄漏
	go func() {
		ticker := time.NewTicker(time.Hour)
		defer ticker.Stop()
		for range ticker.C {
			now := time.Now()
			limiters.Range(func(key, value interface{}) bool {
				info := value.(*limiterInfo)
				if now.Sub(info.lastUsed) > time.Hour {
					limiters.Delete(key)
				}
				return true
			})
		}
	}()

	return func(c *gin.Context) {
		var identifier string

		// 优先用 UserId（已登录用户各自独立限流）
		if userId, exists := c.Get("UserId"); exists {
			identifier = fmt.Sprintf("user_%v", userId)
		}

		// 未登录用户用 IP
		if identifier == "" {
			identifier = fmt.Sprintf("ip_%s", c.ClientIP())
		}

		// 获取或创建该用户/IP 的令牌桶
		now := time.Now()
		limiterInterface, _ := limiters.LoadOrStore(identifier, &limiterInfo{
			limiter:  rate.NewLimiter(rate.Every(tokenInterval), rateLimit),
			lastUsed: now,
		})
		info := limiterInterface.(*limiterInfo)
		info.lastUsed = now

		// 尝试取一个令牌
		if !info.limiter.Allow() {
			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": "请求太频繁，请稍后再试",
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

