package config

import (
	"backend/model"
	"context"
	"log"
	"os"

	"github.com/redis/go-redis/v9"
)

var RDB *redis.Client

var Ctx = context.Background()

func InitRedis() {
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "localhost:6379"
	}

	password := os.Getenv("REDIS_PASSWORD")

	RDB = redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       0,
	})

	if err := RDB.Ping(Ctx).Err(); err != nil {
		log.Fatalf("redis 连接失败，请重试: %v", err)
	}

	log.Println("redis 连接成功")
}

func WarmUpScoreboard() {
	var teams []model.Team
	if err := DB.Find(&teams).Error; err != nil {
		log.Fatalf("读取团队数据失败：%v", err)
	}

	redisMembers := make([]redis.Z, 0, len(teams))
	
	for _, team := range teams {
		redisMembers = append(redisMembers, redis.Z{
			Score:  float64(team.Score),
			Member: team.TeamName,
		})
	}

	if len(redisMembers) > 0 {
		if err := RDB.ZAdd(Ctx, "scoreboard", redisMembers...).Err(); err != nil {
			log.Printf("批量更新排行榜分数失败：%v", err)
		}
	}
	log.Printf("排行榜加载完成，共加载 %d 个团队", len(teams))
}
