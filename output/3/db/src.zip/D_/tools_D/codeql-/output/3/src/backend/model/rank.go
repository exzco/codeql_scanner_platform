package model

type Rank struct {
	TeamName string  `json:"teamName"`
	Score    float64 `json:"score"`
	Rank     int     `json:"rank"`
}
