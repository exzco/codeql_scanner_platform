package handler

import (
	"backend/config"
	"backend/model"
	"backend/util"
	"net/http"

	"github.com/gin-gonic/gin"
)

// @summary 创建比赛题目
// @tags 题目接口
// @param model.CreateChallengeRequest
// @success 200 {object} gin.H "返回创建结果"
// @router /api/auth/admin/challengeCreate [post]
func CreateChallenge(c *gin.Context) {
	var req model.CreateChallengeRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.challenge.CreateChallenge_1"})
		return
	}

	// 验证比赛是否存在
	var game model.Games
	if err := config.DB.Where("game_id = ?", req.GameId).First(&game).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "指定的比赛不存在", "position": "handler.challenge.CreateChallenge_2"})
		return
	}

	// 把 DTO 映射到实际的 DB 模型，再插入 challenges 表
	challenge := model.Challenge{
		ChallengeId:   util.GenerateHashID(req.Title),
		GameId:        req.GameId,
		Title:         req.Title,
		Category:      req.Category,
		Description:   req.Description,
		Score:         req.Score,
		Difficulty:    req.Difficulty,
		IsStatic:      req.IsStatic,
		NeedHostMount: req.NeedHostMount,
		Flag:          req.Flag,
		ImageName:     req.ImageName,
		ContainerPort: req.ContainerPort,
	}

	if err := config.DB.Create(&challenge).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建题目失败", "position": "handler.challenge.CreateChallenge_3"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "success", "data": gin.H{"challenge": challenge}})
}

// @summary 获取比赛题目列表
// @tags 题目接口
// @param model.GetChallengeListRequest
// @success 200 {object} gin.H "返回获取结果"
// @router /api/auth/admin/challengeList [post]
func GetChallengeList(c *gin.Context) {
	var req model.GetChallengeListRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.challenge.GetChallengeList_1"})
		return
	}

	var challenges []model.Challenge
	if err := config.DB.Where("game_id = ?", req.GameId).Find(&challenges).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "获取题目列表失败", "detail": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "success", "data": challenges})
}

// @summary 删除比赛题目
// @tags 题目接口
// @param model.DeleteChallengeRequest
// @success 200 {object} gin.H "返回删除结果"
// @router /api/auth/admin/challengeDelete [post]
func DeleteChallenge(c *gin.Context) {
	var req model.DeleteChallengeRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.challenge.DeleteChallenge_1"})
		return
	}

	if err := config.DB.Where("challenge_id = ? AND game_id = ?", req.ChallengeId, req.GameId).Delete(&model.Challenge{}).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "删除题目失败", "detail": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "题目删除成功"})
}

// @summary 更新比赛题目
// @tags 题目接口
// @param model.UpdateChallengeRequest
// @success 200 {object} gin.H "返回更新结果"
// @router /api/auth/admin/challengeUpdate [post]
func UpdateChallenge(c *gin.Context) {
	var req model.UpdateChallengeRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error(), "position": "handler.challenge.UpdateChallenge_1"})
		return
	}

	var challenge model.Challenge
	if err := config.DB.Where("challenge_id = ? AND game_id = ?", req.ChallengeId, req.GameId).First(&challenge).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "题目未找到"})
		return
	}

	if req.Title != "" {
		challenge.Title = req.Title
	}
	if req.Category != "" {
		challenge.Category = req.Category
	}
	if req.Description != "" {
		challenge.Description = req.Description
	}
	if req.Score != 0 {
		challenge.Score = req.Score
	}
	if req.Difficulty != "" {
		challenge.Difficulty = req.Difficulty
	}
	// bool 类型每次请求都可以直接全量覆盖（如果不传默认是 false）
	challenge.IsStatic = &req.IsStatic
	if req.NeedHostMount != nil {
		challenge.NeedHostMount = *req.NeedHostMount
	}
	if req.Flag != "" {
		challenge.Flag = req.Flag
	}
	if req.ContainerPort != nil {
		challenge.ContainerPort = *req.ContainerPort
	}

	if err := config.DB.Save(&challenge).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "更新题目失败", "detail": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "题目更新成功", "data": challenge})
}
