package model

import (
	"time"
	"github.com/lib/pq"
)

type AdminChangePasswordRequest struct {
	Email string `json:"email" binding:"required"`
	OldPassword string `json:"oldPassword" binding:"required"`
	NewPassword string `json:"newPassword" binding:"required"`
	ConfirmPassword string `json:"confirmPassword" binding:"required"`
}

type AdminDeleteUserRequest struct {
	UserId string `json:"userId" binding:"required"`
	Email string `json:"email" binding:"required"`
}

type AdminListUsersRequest struct {
	Offset int `json:"offset" binding:"required"`
	Size int `json:"size" binding:"required"`
}

type AdminListUsersResponse struct {
	UserId       string      `gorm:"primaryKey;"`
	Username     string    `gorm:"type:varchar(16);uniqueIndex;not null"`
	Email        string    `gorm:"type:varchar(255);uniqueIndex;not null"`
	Role         string    `gorm:"type:varchar(32);not null;default:user"`
	CreatedAt   time.Time `gorm:"autoCreateTime"`
	Score        uint      `gorm:"type:integer;default:0;check:score >= 0"`
	TeamId       *string    `gorm:"default:null"`
}


type AdminListTeamsResponse struct {
	TeamId       string    `gorm:"primaryKey;"`
	TeamName     string         `gorm:"type:varchar(16);uniqueIndex;not null"`
	TeamMembers  pq.StringArray `gorm:"type:text[];not null"`
	TeamScore    uint           `gorm:"type:integer;default:0;check:score >= 0"`
}

type AdminListTeamsRequest struct {
	GameId string `json:"game_id" binding:"required"`
	Size   int    `json:"size" binding:"min=0"`
	Offset int    `json:"offset"`
	Search string `json:"search"`
}

type AdminBanTeamRequest struct {
	TeamId string `json:"teamId" binding:"required"`
	Reason string `json:"reason" binding:"required"`
}

type AdminUnbanTeamRequest struct {
	TeamId string `json:"teamId" binding:"required"`
}

type AdminDeleteTeamRequest struct {
	TeamId string `json:"teamId" binding:"required"`
}