package model

import (
	"github.com/golang-jwt/jwt/v5"
	"github.com/lib/pq"
	_ "gorm.io/gorm"
	"time"
)

type Claims struct {
	UserId string   `json:"user_id"`
	Role   string `json:"role"`
	jwt.RegisteredClaims
}

type User struct {
	UserId       string    `gorm:"primaryKey;"`
	Username     string    `gorm:"type:varchar(16);uniqueIndex;not null"`
	Email        string    `gorm:"type:varchar(255);uniqueIndex;not null"`
	PasswordHash string    `gorm:"type:varchar(255);not null"`
	Role         string    `gorm:"type:varchar(32);not null;default:user"`
	CreatedAt    time.Time `gorm:"autoCreateTime"`
	Score        uint      `gorm:"type:integer;default:0;check:score >= 0"`
	TeamId       *string    `gorm:"default:null"`
	ClientIp     string     `gorm:"type:varchar(255)"`
}

type Team struct {
	TeamId     string      `gorm:"primaryKey;"`
	TeamName   string    `gorm:"type:varchar(64);uniqueIndex;not null"`
	CreatedAt time.Time `gorm:"autoCreateTime"`
	Score      uint      `gorm:"type:integer;default:0;check:score >= 0"`
	InviteCode string    `gorm:"type:varchar(8);uniqueIndex" json:"-"`
	CaptainId  string           `gorm:"not null" json:"captainId"`
	Members    pq.StringArray `gorm:"type:text[];not null;default: '{}'"`
	TeamStatus string    `gorm:"type:varchar(32);not null;default:pending"`
}

type TokenBlacklist struct {
	Token string `gorm:"type:varchar(512);uniqueIndex;not null;primaryKey"`
}

type RegisterRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
	Email    string `json:"email" binding:"required,email"`
}

type LoginRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

type CreateTeamRequest struct {
	TeamName string `json:"teamName" binding:"required"`
}

type JoinTeamRequest struct {
	InviteCode string `json:"inviteCode" binding:"required"` 
}

type ChangePasswordRequest struct {
	OldPassword string `json:"oldPassword" binding:"required"`
	NewPassword string `json:"newPassword" binding:"required"`
}


