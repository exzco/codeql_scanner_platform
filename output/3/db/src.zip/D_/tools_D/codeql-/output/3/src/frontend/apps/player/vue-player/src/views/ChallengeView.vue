<script setup>
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import AppShell from "@shared-ui/components/AppShell.vue";
import { getChallenges, getScoreboard, submitFlag } from "@shared-api/services";

const route = useRoute();
const router = useRouter();
const gameId = route.params.gameId;
const gameName = decodeURIComponent(route.query.gameName || "比赛");

const list = ref([]);
const selectedId = ref("");
const flag = ref("");
const message = ref("");
const top3 = ref([]);

const current = computed(() => list.value.find((x) => String(x.challengeId || x.ChallengeId || x.id) === selectedId.value));

async function load() {
  try {
    const result = await getChallenges(gameId);
    list.value = Array.isArray(result.data) ? result.data : [];
    selectedId.value = list.value[0] ? String(list.value[0].challengeId || list.value[0].ChallengeId || list.value[0].id) : "";

    const rankRes = await getScoreboard();
    top3.value = (Array.isArray(rankRes.data) ? rankRes.data : []).slice(0, 3);
  } catch (e) {
    message.value = e.message || "加载失败";
  }
}

async function onSubmit() {
  if (!selectedId.value || !flag.value.trim()) return;
  try {
    const result = await submitFlag(gameId, selectedId.value, flag.value.trim());
    message.value = result.message || "提交完成";
    flag.value = "";
    await load();
  } catch (e) {
    message.value = e.message || "提交失败";
  }
}

onMounted(load);
</script>

<template>
  <AppShell :title="`${gameName} - 题目`">
    <template #actions>
      <button @click="router.push('/home')">返回大厅</button>
      <button @click="router.push('/team')">队伍页</button>
    </template>

    <div class="layout layout-3">
      <aside class="card list">
        <h3>题目列表</h3>
        <button
          v-for="c in list"
          :key="String(c.challengeId || c.ChallengeId || c.id)"
          class="item"
          :class="{ active: selectedId === String(c.challengeId || c.ChallengeId || c.id) }"
          @click="selectedId = String(c.challengeId || c.ChallengeId || c.id)"
        >
          {{ c.title }}
          <small>{{ c.category }} / {{ c.score }} pts / {{ c.isSolved ? '已解' : '未解' }}</small>
        </button>
      </aside>

      <main class="card detail" v-if="current">
        <h3>{{ current.title }}</h3>
        <p>分类: {{ current.category }}</p>
        <p>分值: {{ current.score }}</p>
        <p>难度: {{ current.difficulty }}</p>
        <div class="row wrap">
          <input v-model="flag" placeholder="输入 flag" />
          <button @click="onSubmit">提交</button>
        </div>
        <p class="hint">{{ message }}</p>
      </main>

      <aside class="card score">
        <h3>排行榜 Top3</h3>
        <p v-for="x in top3" :key="x.rank">{{ x.rank }}. {{ x.teamName }} ({{ x.score }})</p>
      </aside>
    </div>
  </AppShell>
</template>
