package async_tasks

import (
	"backend/config"
	"backend/k8s"
	"backend/model"
	"backend/util/zaphelper"
	"context"
	"encoding/json"
	"fmt"

	"github.com/hibiken/asynq"
)

// 任务载荷定义
type ContainerTaskPayload struct {
	InstanceId    string
	UserId        string
	TeamId        string
	ChallengeId   string
	GameId        string
	Namespace     string
	ImageName     string
	NeedHostMount bool
	DynamicFlag   string
	ContainerPort int32
}

// 压入一个启动容器的 task 到 mq
func EnqueueStartContainer(payload ContainerTaskPayload) error {
	p, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	taskID := fmt.Sprintf("start_container_t%s_c%s", payload.TeamId, payload.ChallengeId)
	task := asynq.NewTask(TypeStartContainer, p, asynq.MaxRetry(3), asynq.Queue("critical"), asynq.TaskID(taskID))
	_, err = AsynqClient.Enqueue(task)
	return err
}

// 压入一个停止容器的 task 到 mq
func EnqueueStopContainer(payload ContainerTaskPayload) error {
	p, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	taskID := fmt.Sprintf("stop_container_%s", payload.InstanceId)
	task := asynq.NewTask(TypeStopContainer, p, asynq.MaxRetry(3), asynq.Queue("common"), asynq.TaskID(taskID))
	_, err = AsynqClient.Enqueue(task)
	return err
}

// 启动容器
func HandleStartContainerTask(ctx context.Context, t *asynq.Task) error {
	var payload ContainerTaskPayload
	if err := json.Unmarshal(t.Payload(), &payload); err != nil {
		return fmt.Errorf("json 解析失败: %v", err)
	}

	// 执行创建 k8s 资源动作
	_, err := k8s.CreateChallengeInstance(ctx, payload.Namespace, payload.InstanceId, payload.ImageName, payload.NeedHostMount, payload.DynamicFlag, config.ChalDomain, payload.ContainerPort)

	// 最后再去修改数据库状态，让用户看到正在运行
	var container model.ContainerInstance
	if updateErr := config.DB.Where("instance_id = ?", payload.InstanceId).First(&container).Error; updateErr == nil {
		if err != nil {
			config.DB.Model(&container).Update("status", "error")
			return err
		} else {
			config.DB.Model(&container).Update("status", "running")
		}
	}
	return nil
}

func HandleStopContainerTask(ctx context.Context, t *asynq.Task) error {
	var payload ContainerTaskPayload
	if err := json.Unmarshal(t.Payload(), &payload); err != nil {
		return fmt.Errorf("json 解析失败: %v", err)
	}

	err := k8s.DeleteChallengeInstance(ctx, payload.Namespace, payload.InstanceId)

	var container model.ContainerInstance
	if updateErr := config.DB.Where("instance_id = ?", payload.InstanceId).First(&container).Error; updateErr == nil {
		if err != nil {
			zaphelper.Sugar.Warnw("k8s 销毁靶机发生一些问题，但流程继续", "error", err, "instance_id", payload.InstanceId)
		}

		config.DB.Model(&container).Update("status", "destroyed")
	}
	return nil
}
