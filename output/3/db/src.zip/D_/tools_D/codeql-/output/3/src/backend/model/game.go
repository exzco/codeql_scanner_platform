package model

import "time"

// DB model 用于数据库映射
// DB model 用于数据库映射
type Games struct {
	GameId          string    `gorm:"primaryKey;type:varchar(16);not null"`
	Title           string    `gorm:"type:varchar(128);uniqueIndex;not null"`
	Description     string    `gorm:"type:text"`
	StartTime       time.Time `gorm:"not null"`
	EndTime         time.Time `gorm:"not null"`
	Status          string    `gorm:"type:varchar(16);not null;default:upcoming"` // upcoming, ongoing, ended
	TeamNumberLimit int       `gorm:"type:integer;default:0;check:team_number_limit >= 0"`
}

// data transfer object 用于传输
type GameRequest struct {
	Title       string    `json:"title" binding:"required"`
	Description string    `json:"description" binding:"required"`
	StartTime   time.Time `json:"startTime" binding:"required"`
	EndTime     time.Time `json:"endTime" binding:"required"`
}

type DeleteGameRequest struct {
	GameId string `json:"gameId" binding:"required"`
}

type UpdateGameRequest struct {
	GameId      string    `json:"gameId" binding:"required"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	StartTime   time.Time `json:"startTime"`
	EndTime     time.Time `json:"endTime"`
}
