package route

import (
	"backend/config"
	"backend/handler"
	"backend/middleware"
	"time"

	"github.com/gin-gonic/gin"
)

func SetupRouter() *gin.Engine {
	r := gin.Default()
	r.Use(middleware.CORS())


	apiV1 := r.Group("/api")

	{
		publicRouter := apiV1.Group("/public")

		{
			publicRouter.POST("/login", handler.Login)
			publicRouter.POST("/register", handler.Register)
		}

		protectedRouter := apiV1.Group("/auth")
		{
			protectedRouter.Use(middleware.AuthMiddleware(config.JWTSecretKey))
			protectedRouter.Use(middleware.RateLimiter(10, time.Second)) // 限流

			protectedRouter.POST("/logout", handler.Logout)

			// 比赛相关 api
			protectedRouter.GET("/gameList", handler.GetGameList)
			protectedRouter.GET("/games/:id", handler.GetGameDetail)
			protectedRouter.GET("/games/:id/challenges", handler.GetChallenges)
			protectedRouter.POST("/games/:id/challenges/:challengeId/submit", handler.SubmitFlag)
			
			// 靶机容器 API
			protectedRouter.POST("/games/:id/challenges/:challengeId/start", handler.StartChallengeContainer)
			protectedRouter.POST("/games/:id/challenges/:challengeId/extend", handler.ExtendChallengeContainer)
			protectedRouter.POST("/games/:id/challenges/:challengeId/destroy", handler.DestroyChallengeContainer)
			
			protectedRouter.GET("/scoreboard", handler.GetScoreboard)

			// 团队 API
			protectedRouter.POST("/team/create", handler.CreateTeam)
			protectedRouter.POST("/team/join", handler.JoinTeam)
			protectedRouter.POST("/team/leave", handler.LeaveTeam)
			protectedRouter.POST("/team/info", handler.GetTeamInfo)

			// 个人信息 API
			protectedRouter.GET("/user/profile", handler.GetProfile)
			protectedRouter.POST("/user/profile/password", handler.ChangePassword)
			// protectedRouter.GET("/user/profile/email",handler.ChangeEmail)

			adminRouter := protectedRouter.Group("/admin")
			{
				adminRouter.Use(middleware.AdminAuthMiddleware())
				// admin 比赛管理 api
				adminRouter.POST("/gameCreate", handler.CreateGame)
				adminRouter.POST("/gameDelete", handler.DeleteGame)
				adminRouter.POST("/gameUpdate", handler.UpdateGame)

				// admin 题目管理 api 
				adminRouter.POST("/challengeCreate", handler.CreateChallenge)
				adminRouter.POST("/challengeList", handler.GetChallengeList)
				adminRouter.POST("/challengeDelete", handler.DeleteChallenge)
				adminRouter.POST("/challengeUpdate", handler.UpdateChallenge)

				// admin 用户管理 api
				adminRouter.POST("/changePassword", handler.AdminChangeUsersPassword)
				adminRouter.POST("/listUsers", handler.AdminListUsers)
				adminRouter.POST("/deleteUser",handler.AdminDeleteUser)

				// admin 团队管理 api
				adminRouter.POST("/listTeams",handler.AdminListTeams)
				adminRouter.POST("/banTeams",handler.AdminBanTeam)
				adminRouter.POST("/unbanTeams",handler.AdminUnbanTeam)
				adminRouter.POST("/deleteTeam",handler.AdminDeleteTeam)
				// adminRouter.POST("/approveTeam",handler.AdminApproveTeam)

				// admin 容器管理 api
				adminRouter.POST("/containerList", handler.AdminListContainers)
				adminRouter.POST("/containerDelete", handler.AdminDeleteContainer)
			}
		}
	}

	return r
}
