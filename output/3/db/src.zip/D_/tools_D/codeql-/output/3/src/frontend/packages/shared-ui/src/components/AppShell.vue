<script setup>
defineProps({
  title: {
    type: String,
    default: "",
  },
});
</script>

<template>
  <div class="page">
    <header class="topbar">
      <h2>{{ title }}</h2>
      <div class="row">
        <slot name="actions" />
      </div>
    </header>
    <slot />
  </div>
</template>
