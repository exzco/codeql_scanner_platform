package k8s

import (
	"context"
	"fmt"
	"os"
	"path/filepath"

	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
)

var Clientset *kubernetes.Clientset

func InitK8sClient() error {
	var config *rest.Config
	var err error

	config, err = rest.InClusterConfig()
	if err != nil {
		kubeconfig := filepath.Join(os.Getenv("USERPROFILE"), ".kube", "config")
		if os.Getenv("KUBECONFIG") != "" {
			kubeconfig = os.Getenv("KUBECONFIG")
		}

		config, err = clientcmd.BuildConfigFromFlags("", kubeconfig)
		if err != nil {
			return fmt.Errorf("failed to build kubeconfig: %v", err)
		}
	}

	Clientset, err = kubernetes.NewForConfig(config)
	if err != nil {
		return fmt.Errorf("failed to create k8s client: %v", err)
	}

	return nil
}

func ensureNamespace(ctx context.Context, namespace string) error {
	if Clientset == nil {
		return fmt.Errorf("k8s client not initialized")
	}

	_, err := Clientset.CoreV1().Namespaces().Get(ctx, namespace, metav1.GetOptions{})
	if err == nil {
		return nil
	}

	ns := &corev1.Namespace{
		ObjectMeta: metav1.ObjectMeta{
			Name: namespace,
		},
	}
	_, err = Clientset.CoreV1().Namespaces().Create(ctx, ns, metav1.CreateOptions{})
	return err
}

func CreateChallengeInstance(ctx context.Context, namespace, instanceID, imageName string, needHostMount bool, dynamicFlag, baseDomain string, containerPort int32) (string, error) {
	if Clientset == nil {
		return "", fmt.Errorf("k8s client not initialized")
	}

	// 1. 确保 Namespace 存在
	if err := ensureNamespace(ctx, namespace); err != nil {
		return "", fmt.Errorf("failed to ensure namespace %s: %v", namespace, err)
	}

	appName := fmt.Sprintf("chal-%s", instanceID)
	labels := map[string]string{
		"app": appName,
	}

	var volumeMounts []corev1.VolumeMount
	var volumes []corev1.Volume
	if needHostMount {
		volumeMounts = []corev1.VolumeMount{
			{
				Name:      "host-root",
				MountPath: "/host",
			},
		}

		hostPathType := corev1.HostPathDirectory
		volumes = []corev1.Volume{
			{
				Name: "host-root",
				VolumeSource: corev1.VolumeSource{
					HostPath: &corev1.HostPathVolumeSource{
						Path: "/",
						Type: &hostPathType,
					},
				},
			},
		}
	}

	// 2. 创建 Deployment
	replicas := int32(1)
	deployment := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      appName,
			Namespace: namespace,
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: labels,
			},
			Template: corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: labels,
				},
				Spec: corev1.PodSpec{
					Containers: []corev1.Container{
						{
							Name:  "challenge-container",
							Image: imageName,
							Ports: []corev1.ContainerPort{
								{
									ContainerPort: containerPort,
								},
							},
							Env: []corev1.EnvVar{
								{
									Name:  "FLAG",
									Value: dynamicFlag,
								},
							},
							VolumeMounts: volumeMounts,
						},
					},
					Volumes: volumes,
				},
			},
		},
	}

	_, err := Clientset.AppsV1().Deployments(namespace).Create(ctx, deployment, metav1.CreateOptions{})
	if err != nil {
		return "", fmt.Errorf("failed to create deployment: %v", err)
	}

	// 3. 创建 Service
	service := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:      appName,
			Namespace: namespace,
		},
		Spec: corev1.ServiceSpec{
			Selector: labels,
			Ports: []corev1.ServicePort{
				{
					Protocol:   corev1.ProtocolTCP,
					Port:       containerPort,
					TargetPort: intstr.FromInt(int(containerPort)),
				},
			},
			Type: corev1.ServiceTypeClusterIP,
		},
	}

	_, err = Clientset.CoreV1().Services(namespace).Create(ctx, service, metav1.CreateOptions{})
	if err != nil {
		Clientset.AppsV1().Deployments(namespace).Delete(ctx, appName, metav1.DeleteOptions{})
		return "", fmt.Errorf("failed to create service: %v", err)
	}

	// 4. 创建 Ingress
	subdomain := fmt.Sprintf("%s.%s", appName, baseDomain)
	pathType := networkingv1.PathTypePrefix

	ingressClassName := "nginx"
	ingress := &networkingv1.Ingress{
		ObjectMeta: metav1.ObjectMeta{
			Name:      appName,
			Namespace: namespace,
		},
		Spec: networkingv1.IngressSpec{
			IngressClassName: &ingressClassName,
			Rules: []networkingv1.IngressRule{
				{
					Host: subdomain,
					IngressRuleValue: networkingv1.IngressRuleValue{
						HTTP: &networkingv1.HTTPIngressRuleValue{
							Paths: []networkingv1.HTTPIngressPath{
								{
									Path:     "/",
									PathType: &pathType,
									Backend: networkingv1.IngressBackend{
										Service: &networkingv1.IngressServiceBackend{
											Name: appName,
											Port: networkingv1.ServiceBackendPort{
												Number: containerPort,
											},
										},
									},
								},
							},
						},
					},
				},
			},
		},
	}

	_, err = Clientset.NetworkingV1().Ingresses(namespace).Create(ctx, ingress, metav1.CreateOptions{})
	if err != nil {
		Clientset.CoreV1().Services(namespace).Delete(ctx, appName, metav1.DeleteOptions{})
		Clientset.AppsV1().Deployments(namespace).Delete(ctx, appName, metav1.DeleteOptions{})
		return "", fmt.Errorf("failed to create ingress: %v", err)
	}

	return subdomain, nil
}

// DeleteChallengeInstance 清理对应挑战的所有资源
func DeleteChallengeInstance(ctx context.Context, namespace, instanceID string) error {
	if Clientset == nil {
		return fmt.Errorf("k8s client not initialized")
	}

	appName := fmt.Sprintf("chal-%s", instanceID)

	_ = Clientset.NetworkingV1().Ingresses(namespace).Delete(ctx, appName, metav1.DeleteOptions{})
	_ = Clientset.CoreV1().Services(namespace).Delete(ctx, appName, metav1.DeleteOptions{})
	return Clientset.AppsV1().Deployments(namespace).Delete(ctx, appName, metav1.DeleteOptions{})
}
