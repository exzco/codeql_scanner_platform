package main

import (
	"backend/async_tasks"
	"backend/config"
	"backend/cronJobs"
	"backend/k8s"
	"backend/route"
	"backend/util/zaphelper"
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"
)

// @title           backend API
// @version         1.0
// @description     后端接口说明
// @host            localhost:23134
// @BasePath        /api
func main() {

	// 读取 .env 赋值一些敏感信息到环境变量中
	if err := godotenv.Load(); err != nil {
		log.Fatalf("load .env failed: %v", err)
	}
	secret := os.Getenv("JWT_SECRET")
	if secret == "" {
		log.Fatal("JWT_SECRET is required")
	}
	config.JWTSecretKey = secret

	//
	if domain := os.Getenv("CHAL_DOMAIN"); domain != "" {
		config.ChalDomain = domain
	}

	// 初始化日志中心
	zaphelper.InitZap()
	defer zaphelper.CloseZap()

	// 初始化数据库
	dbConfig := config.InitDBConfig()
	db, err := config.InitDB(dbConfig)
	if err != nil {
		log.Fatalf("init db failed: %v", err)
	}
	config.DB = db

	// 初始化 redis
	config.InitRedis()
	config.WarmUpScoreboard()

	// 初始化 消息队列
	async_tasks.InitMessageQuene()

	// 初始化 k8s
	if err := k8s.InitK8sClient(); err != nil {
		log.Fatalf("init k8s client failed: %v", err)
	}

	// 注册路由
	r := route.SetupRouter()

	// 启动后台定时任务查询状态，纠正前后不一致的问题
	cronJobs.StartContainerJob()

	// 启动 HTTP 服务
	srv := &http.Server{
		Addr:    ":23134",
		Handler: r,
	}

	// 在独立协程中运行服务，避免阻塞
	go func() {
		log.Printf("服务启动在: http://localhost:23134")
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("监听失败: %v", err)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("正在关闭服务...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		log.Fatal("强制关闭服务: ", err)
	}

	log.Println("服务已退出.")
}
