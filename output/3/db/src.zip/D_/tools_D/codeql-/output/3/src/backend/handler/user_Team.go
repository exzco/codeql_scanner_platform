package handler

import (
	"backend/config"
	"backend/model"
	"backend/util"
	"log"
	"net/http"
	"github.com/redis/go-redis/v9"

	"github.com/gin-gonic/gin"
)

// @summary 创建团队
// @tags 团队接口
// @success 200 {object} gin.H "返回团队信息"
// @router /api/auth/team/create [post]
func CreateTeam(c *gin.Context) {
	var req model.CreateTeamRequest 
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":err.Error(),"position":"handler.Team.CreateTeam_1"})
		return
	}

	captainId := c.GetString("UserId")

	var user model.User
	// 1. 检查用户是否已经加入团队
	if err := config.DB.Where("user_id = ?",captainId).First(&user).Error; err != nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":err.Error(),"position":"handler.Team.CreateTeam_2"})
		return
	} 
	if user.TeamId != nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":"user has already joined a team","position":"handler.Team.CreateTeam_3"})
		return
	}

	// 2. 检查团队名称是否已经存在
	var exists model.Team
	if err := config.DB.Where("team_name = ?",req.TeamName).First(&exists).Error; err == nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":"team name already exists","position":"handler.Team.CreateTeam_4"})
		return
	}

	// 3. 生成团队ID
	teamId := util.GenerateTeamId(req.TeamName)
	
	team := model.Team{
		TeamName:   req.TeamName,
		InviteCode: util.GenerateInviteCode(),
		CaptainId:  captainId,
		TeamId:     teamId,
		Members:    []string{user.Username}, // 1. 创建时直接将队长加入成员列表
	}

	// 加入数据库
	if err := config.DB.Create(&team).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.Team.CreateTeam_6"})
		return
	}

	// 更新用户所属团队 ID
	if err := config.DB.Model(&user).Select("team_id").Updates(map[string]interface{}{"team_id": team.TeamId}).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "更新用户战队信息失败", "position": "handler.Team.CreateTeam_7"})
		return
	}

	// 加入 redis
	if err := config.RDB.ZAdd(config.Ctx,"scoreboard",redis.Z{
		Score: 0,
		Member: team.TeamName,
	}).Err(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error(), "position": "handler.Team.CreateTeam_8"})
		return
	}

	log.Printf("团队创建成功: %s, 邀请码: %s", team.TeamName, team.InviteCode)
	c.JSON(http.StatusOK, gin.H{
		"message":    "团队创建成功",
		"teamName":   team.TeamName,
		"inviteCode": team.InviteCode,
	})
}


// @summary 加入队伍
// @tags 团队接口
// @router /api/auth/team/join [post]
// @success 200 {object} gin.H "返回团队信息"
func JoinTeam(c *gin.Context) {
	var req model.JoinTeamRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":err.Error(),"position":"handler.Team.JoinTeam_1"})
		return
	}

	userId := c.GetString("UserId")

	var user model.User
	// 1. 检查用户是否已经加入团队
	if err := config.DB.Where("user_id = ?",userId).First(&user).Error; err != nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":err.Error(),"position":"handler.Team.JoinTeam_2"})
		return
	} 
	if user.TeamId != nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":"user has already joined a team","position":"handler.Team.JoinTeam_3"})
		return
	}

	// 2. 检查邀请码是否正确
	var team model.Team
	if err := config.DB.Where("invite_code = ?",req.InviteCode).First(&team).Error; err != nil {
		c.JSON(http.StatusBadRequest,gin.H{"error":"invite code is incorrect","position":"handler.Team.JoinTeam_4"})
		return
	}

	// 3. 加入团队
	if err := config.DB.Model(&user).Update("team_id",team.TeamId).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.Team.JoinTeam_5"})
		return
	}

	// 更新团队成员
	if err := config.DB.Model(&team).Update("members",append(team.Members,user.Username)).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.Team.JoinTeam_6"})
		return
	}

	log.Printf("加入团队成功: %s", team.TeamName)
	c.JSON(http.StatusOK, gin.H{
		"message":    "加入团队成功",
		"teamName":   team.TeamName,
	})
}

// @summary 退出团队
// @tags 团队接口
// @router /api/auth/team/leave [post]
func LeaveTeam(c *gin.Context) {
	userId := c.GetString("UserId")

	// 1. 查询用户
	var user model.User
	if err := config.DB.Where("user_id = ?", userId).First(&user).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "用户不存在"})
		return
	}
	if user.TeamId == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "你不在任何团队中"})
		return
	}

	// 2. 队长不能直接退出
	var team model.Team
	if err := config.DB.Where("team_id = ?", user.TeamId).First(&team).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "团队不存在"})
		return
	}
	if team.CaptainId == userId {
		c.JSON(http.StatusBadRequest, gin.H{"error": "队长不能退出，请先转让队长或解散团队"})
		return
	}

	// 3. 退出团队
	if err := config.DB.Model(&user).Update("team_id", nil).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "退出团队失败"})
		return
	}

	// 4. 更新团队成员
	if err := config.DB.Model(&team).Update("members",util.Remove(team.Members,user.Username)).Error; err != nil {
		c.JSON(http.StatusInternalServerError,gin.H{"error":err.Error(),"position":"handler.Team.JoinTeam_6"})
		return
	}

	

	c.JSON(http.StatusOK, gin.H{"message": "退出团队成功"})
}


// @summary 查看团队信息
// @tags 团队接口
// @router /api/auth/team/info [post]
func GetTeamInfo(c *gin.Context) {
	userId := c.GetString("UserId")

	// 1. 查询用户所属团队
	var user model.User
	if err := config.DB.Where("user_id = ?", userId).First(&user).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "用户不存在"})
		return
	}
	if user.TeamId == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "你不在任何团队中"})
		return
	}

	// 2. 查询团队信息
	var team model.Team
	if err := config.DB.Where("team_id = ?", user.TeamId).First(&team).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "团队不存在"})
		return
	}

	// 3. 查询团队成员列表
	var members []model.User
	config.DB.Where("team_id = ?", team.TeamId).Find(&members)

	// 构造成员响应
	type MemberInfo struct {
		UserId   string `json:"userId"`
		Username string `json:"username"`
		Score    uint   `json:"score"`
	}

	memberList := make([]MemberInfo, len(members))
	for i, m := range members {
		memberList[i] = MemberInfo{
			UserId:   m.UserId,
			Username: m.Username,
			Score:    m.Score,
		}
	}

	// 4. 构造响应，队长能看到邀请码，普通成员看不到
	resp := gin.H{
		"teamName":  team.TeamName,
		"captainId": team.CaptainId,
		"score":     team.Score,
		"members":   memberList,
	}
	if team.CaptainId == userId {
		resp["inviteCode"] = team.InviteCode 
	}

	c.JSON(http.StatusOK, gin.H{"message": "success", "data": resp})
}
